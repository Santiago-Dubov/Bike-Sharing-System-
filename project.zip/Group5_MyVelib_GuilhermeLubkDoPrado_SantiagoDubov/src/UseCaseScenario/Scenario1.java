package UseCaseScenario;

import java.time.LocalDateTime;

import myVelib.core.CoreMyVelib;
import myVelib.coreAttributes.Station;
import myVelib.coreAttributes.User;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.supportClasses.Coord;

public class Scenario1 {
	public static void main(String[] args) {
		CoreMyVelib core = new CoreMyVelib();
		int N = 13; //num stations
		int M = 100; //num parking spaces
		int nBikes = (int) (0.7*M);// number of bikes requested by user
		double R = 10;//radius 10km in this case
		int n1 = (int) Math.sqrt(N) + 1;//variable used to evenly distribute stations
		int n2 = (int) M/N + 1;// variable used to evenly distribute stations
		int eBikesPerStation = (int) (0.21*M/N) + 1;
		int mBikesPerStation = (int) (0.49*M/N) + 1;
		//System.out.println(mBikesPerStation + "  " + eBikesPerStation);
		for (int i = 1; i < n1+1; i++) {
			//the for loop is used to randomly distribute the stations over the chosen area R^2
			for (int j = 1; j < n1+1; j++) {
				if (core.getStationList().size() < N) {
					String stationType;
					if (Math.random() < 0.5) {
						stationType = "plus";
					}
					else {
						stationType = "standard";
					}
					try {
						// a new station is created at the location specified and it is populated with the number of 
						// electrical and mechanical bikes required.
						Coord location = new Coord(i*R/(n1+1),j*R/(n1+1));
						core.addStation(location, stationType, Math.min(n2, M));
						int stationID = core.getStationByLocation(location).getStationID();
						//core.displayAllStations();
						for (int k = 0; k < eBikesPerStation; k++) {
							if (core.getTotalNumberOfBikes() < nBikes) {
								core.addBike(stationID,  "Electrical");
							}
						}
						for (int k = 0; k < mBikesPerStation; k++) {
							if (core.getTotalNumberOfBikes() < nBikes) {
								core.addBike(stationID, "mechanical");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					M -= Math.min(n2, M);
				}
				else {
					break;
				}
			}
		}
		System.out.println("\n //All stations present in the network\n");
		core.displayAllStations();
		
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
			core.addUser("Santiago", "none", new Coord(1, 2), "3940950394030040");
			core.addUser("Guilherme", "vlibre", new Coord(3, 5), "1234567890892394");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("\n //All users present on the network\n");
		core.displayAllUsers();
		
		//ride planning and bike renting functions demonstration
		try {
			User santiago = core.getUserByCreditCard("3940950394030040");
			System.out.println("\n //The user Santiago requests a ride planning from " + santiago.getUserGPSLocation() + " to [5.0,8.0] and would "
					+ "like to use an electric bike");
			System.out.println(" //He receives the following output: \n");
			core.planRide(santiago.getUserGPSLocation(), new Coord(5,8), "electrical", "standard");
			int userID = santiago.getUserID();
			Station start = core.getStationByLocation(new Coord(2,2));
			Station end = core.getStationByLocation(new Coord(4,8));
			
			System.out.println("\n //State of stations before ride has occured \n");
			core.displayStation(start.getStationID());
			core.displayStation(end.getStationID());
			System.out.println("\n");
			
			System.out.println(" //The user's position is updated and he request a bike at 15:30 "
					+ "\n //he returns it at 16:31 at the second station\n");
			core.updateUser(userID, start.getStationGPSLocation());
			core.rentBike(userID, start.getStationID(), "electrical", LocalDateTime.of(2020, 5, 3, 15, 30));
			core.updateUser(userID, end.getStationGPSLocation());
			core.returnBike(userID, end.getStationID(), LocalDateTime.of(2020, 5, 3, 16, 31));
			
			System.out.println("\n //State of stations after ride has occured \n");
			core.displayStation(start.getStationID());
			core.displayStation(end.getStationID());
			System.out.println("\n //State of user after ride\n");
			
			core.displayUser(userID);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Sorting stations demonstration
		try {
			User santiago = core.getUserByCreditCard("3940950394030040");
			Station st1 = core.getStationByLocation(new Coord(4,8));
			core.rentBike(santiago.getUserID(), st1.getStationID(), "electrical", LocalDateTime.of(2020, 5, 3, 19, 30));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			System.out.println("\n //The following stations have been sorted by occupancy (instantaneous) using the sortStation function \n");
			core.displaySortedStations("mostOccupied");
			System.out.println("\n //The following stations have been sorted by total number of operations using the sortStation function \n");
			core.displaySortedStations("mostUsed");
		} catch (UnknownOperationTypeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
	}

}
