package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import myVelib.coreAttributes.Station;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.observersReports.StationReport;
import myVelib.ridePlanner.StandardPlanner;
import myVelib.supportClasses.Coord;

class StandardPlannerTest {

	@Test 
	void testGetClosestStartStation() {
		// tests if the correct closest station is chosen and if it has bikes of the desired bike type available
		ArrayList<Station> stationList = new ArrayList<Station>();
		Station s1 = new Station(new Coord(1,0),"STANDARD",10);
		Station s2 = new Station(new Coord(0,2),"STANDARD",10);
		StationReport sr = new StationReport();
		s1.attach(sr);
		s2.attach(sr);
		sr.addStation(s1);
		sr.addStation(s2);
		
		//Populate s1 with i electrical bikes
				for (int i = 0; i < 5; i++) {
					try {
						s1.addNewBike("ELECTRICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
		//Populate s1 with i mechanical bikes
				for (int i = 0; i < 5; i++) {
					try {
						s1.addNewBike("MECHANICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
				
		//Populate s2 with i electrical bikes
				for (int i = 0; i < 2; i++) {
					try {
						s2.addNewBike("ELECTRICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
		//Populate s2 with i mechanical bikes
				for (int i = 0; i < 3; i++) {
					try {
						s2.addNewBike("MECHANICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
		
		stationList.add(s1);
		stationList.add(s2);
		Station start;
		try {
			start = StandardPlanner.getClosestStartStation(new Coord(0,0), stationList, "ELectrical");
			assertTrue(start.equals(s1));
			assertTrue(start.hasAvailableBikes("Electrical"));
		} catch (NoBikesAvailableException e) {
			
		}
		
	}
	
	@Test 
	void testGetClosestStartStationNoBikesAvailable() {
		// test that an exception is returned if no bikes of the desired type exist on the network
		ArrayList<Station> stationList = new ArrayList<Station>();
		Station s1 = new Station(new Coord(1,0),"STANDARD",10);
		Station s2 = new Station(new Coord(0,2),"STANDARD",10);
		StationReport sr = new StationReport();
		s1.attach(sr);
		s2.attach(sr);
		sr.addStation(s1);
		sr.addStation(s2);
		

		//Populate s1 with i mechanical bikes
		for (int i = 0; i < 5; i++) {
			try {
				s1.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		//Populate s2 with i mechanical bikes
		for (int i = 0; i < 3; i++) {
			try {
				s2.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		stationList.add(s1);
		stationList.add(s2);
		@SuppressWarnings("unused")
		Station start;
		try {
			start = StandardPlanner.getClosestStartStation(new Coord(0,0), stationList, "ELectrical");
		} catch (NoBikesAvailableException e) {
		
			assert(true);
		}
		
	}
	@Test
	void testGetClosestEndStation() {
		//test that the final station returned is the closest and has available parking spaces
		ArrayList<Station> stationList = new ArrayList<Station>();
		Station s1 = new Station(new Coord(1,0),"STANDARD",10);
		Station s2 = new Station(new Coord(0,2),"STANDARD",10);
		StationReport sr = new StationReport();
		s1.attach(sr);
		s2.attach(sr);
		sr.addStation(s1);
		sr.addStation(s2);
		
		//Populate s1 with i electrical bikes
		for (int i = 0; i < 5; i++) {
			try {
				s1.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate s1 with i mechanical bikes
		for (int i = 0; i < 4; i++) {
			try {
				s1.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		//Populate s2 with i electrical bikes
		for (int i = 0; i < 2; i++) {
			try {
				s2.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate s2 with i mechanical bikes
		for (int i = 0; i < 3; i++) {
			try {
				s2.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		stationList.add(s1);
		stationList.add(s2);
		Station endStation;
		try {
			endStation = StandardPlanner.getClosestEndStation(new Coord(0,0), stationList);
			assertTrue(endStation.equals(s1));
			assertTrue(endStation.hasAvailableParkingSpaces());
		} catch (NoVacancyException e) {
			
		}
		
	}
	
	@Test
	void testGetClosestEndStationThrowsException() {
		//test that if the network is full a noVacancyException is returned
		ArrayList<Station> stationList = new ArrayList<Station>();
		Station s1 = new Station(new Coord(1,0),"STANDARD",10);
		StationReport sr = new StationReport();
		s1.attach(sr);
		sr.addStation(s1);
		
		//Populate s1 with i electrical bikes
				for (int i = 0; i < 5; i++) {
					try {
						s1.addNewBike("ELECTRICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
				//Populate s1 with i mechanical bikes
				for (int i = 0; i < 5; i++) {
					try {
						s1.addNewBike("MECHANICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
				
				
		
		stationList.add(s1);
		try {
			@SuppressWarnings("unused")
			Station endStation = StandardPlanner.getClosestEndStation(new Coord(0,0), stationList);
		} catch (NoVacancyException e) {
			assert(true);
		}
		
		
	}
	
	@Test
	void testStartAndEndStationNotTheSame(){
		// test to check that if there is only one station with available bikes and parking spaces, then a route is not possible. 
		ArrayList<Station> stationList = new ArrayList<Station>();
		Station s1 = new Station(new Coord(1,0),"STANDARD",10);
		Station s2 = new Station(new Coord(5,5),"STANDARD",10);
		StationReport sr = new StationReport();
		s1.attach(sr);
		s2.attach(sr);
		sr.addStation(s1);
		sr.addStation(s2);
		
		//Populate s1 with i electrical bikes
				for (int i = 0; i < 3; i++) {
					try {
						s1.addNewBike("ELECTRICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
				//Populate s1 with i mechanical bikes
				for (int i = 0; i < 2; i++) {
					try {
						s1.addNewBike("MECHANICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
				
				//Populate s2 with i electrical bikes
				for (int i = 0; i < 5; i++) {
					try {
						s2.addNewBike("ELECTRICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
				//Populate s2 with i mechanical bikes
				for (int i = 0; i < 5; i++) {
					try {
						s2.addNewBike("MECHANICAL");
					} catch (NoVacancyException e) {
						fail("Threw exception");
					}
				}
		
		stationList.add(s1);
		stationList.add(s2);
		try {
			StandardPlanner.getStartEndStations(new Coord(0,0), new Coord(5,5), "Electrical", stationList);
		} catch (Exception e) {
			assert(true);
		}
	}
	

}
