package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import myVelib.supportClasses.SerialNumberGenerator;

class SerialNumberGeneratorTest {

	@Test
	void testGetInstance() {
		SerialNumberGenerator s1 = SerialNumberGenerator.getInstance();
		SerialNumberGenerator s2 = SerialNumberGenerator.getInstance();
		assertTrue(s1.equals(s2));
	}

	@Test
	void testGetNextSerialNumber() {
		SerialNumberGenerator s2 = SerialNumberGenerator.getInstance();
		int serial1 = s2.getNextSerialNumber();
		int serial2 = s2.getNextSerialNumber();
		int serial3 = s2.getNextSerialNumber();
		assertFalse(serial1 == serial2);
		assertFalse(serial2 == serial3);
		assertFalse(serial1 == serial3);
		
	}

}
