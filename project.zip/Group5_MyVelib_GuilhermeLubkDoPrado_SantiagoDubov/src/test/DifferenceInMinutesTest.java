package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;
import myVelib.supportClasses.DifferenceInMinutes;

class DifferenceInMinutesTest {

	@Test
	void testIfResultIsCorrect() {
		LocalDateTime startTime = LocalDateTime.of(2020, 5, 31, 23, 15);
		LocalDateTime endTime = LocalDateTime.of(2020, 6, 4, 06, 00);
		try {
			assertTrue(DifferenceInMinutes.returnDifferenceInMinutes(startTime, endTime) == 4725);
		} catch (EndTimeIsPriorToStartTimeSException e) {
			
		}
	}
	
	void testIfThrowsException() {
		LocalDateTime startTime = LocalDateTime.of(2020, 7, 31, 23, 15);
		LocalDateTime endTime = LocalDateTime.of(2020, 6, 4, 06, 00);
		try {
			@SuppressWarnings("unused")
			int dif = DifferenceInMinutes.returnDifferenceInMinutes(startTime, endTime);
		} catch (EndTimeIsPriorToStartTimeSException e) {
			assertTrue(true);
		}
	}

}
