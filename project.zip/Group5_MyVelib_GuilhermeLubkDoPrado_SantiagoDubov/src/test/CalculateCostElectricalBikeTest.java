package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import myVelib.coreAttributes.User;
import myVelib.observersReports.UserReport;
import myVelib.pricingCalculator.CalculateCostElectricalBike;
import myVelib.supportClasses.Coord;

class CalculateCostElectricalBikeTest {

	@Test
	void testNoCardShortRide() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "none", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		
		assertTrue(ce.calculatePrice(user) == 2);
	}
	
	@Test
	void testNoCardLongRide() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "none", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 19, 37));
		
		assertTrue(ce.calculatePrice(user) == 6);
	}
	
	@Test
	void testVlibreShortRide() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "Vlibre", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		
		assertTrue(ce.calculatePrice(user) == 1);
	}
	
	@Test
	void testVlibre127MinRideFewCredits() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "Vlibre", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 19, 37));
		
		user.addTimeBalance(10);
		
		assertTrue(ce.calculatePrice(user) == 3);
	}
	
	@Test
	void testVlibre127MinRideManyCredits() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "Vlibre", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 19, 37));
		
		user.addTimeBalance(80);

		assertTrue(ce.calculatePrice(user) == 1);
	}
	
	@Test
	void testVmaxShortRide() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "Vmax", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		
		assertTrue(ce.calculatePrice(user) == 0);
	}
	
	@Test
	void testVmax127MinRideFewCredits() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "Vmax", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 19, 37));
		
		user.addTimeBalance(10);
		
		assertTrue(ce.calculatePrice(user) == 1);
	}
	
	@Test
	void testVmax127MinRideManyCredits() {
		CalculateCostElectricalBike ce = new CalculateCostElectricalBike();
		
		UserReport ur = new UserReport();
		User user = new User("Arnault Lapitre", "Vmax", new Coord(5, 15), "5555444455554444", ur);
		ur.addUser(user);
		user.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		user.setEndRentTime(LocalDateTime.of(2020, 5, 3, 19, 37));
		
		user.addTimeBalance(80);
		
		assertTrue(ce.calculatePrice(user) == 0);
	}

}
