package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import myVelib.bikeFactory.Bike;
import myVelib.bikeFactory.ElectricalBike;
import myVelib.coreAttributes.ParkingSpace;
import myVelib.coreAttributes.Station;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.observersReports.StationReport;
import myVelib.supportClasses.Coord;

class StationTest {

	@Test
	void testStationCreation() {
		Station st = new Station(new Coord(25, 25), "plus", 50);//20 21
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		
		
		int freedSpaces = 0;
		int occupiedSpaces = 0;
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		
		for (ParkingSpace p : st.getParkingSpaces()) {
			if (p.isOccupied()) {
				occupiedSpaces += 1;
			}else {
				freedSpaces += 1;
			}
		}
		for (Bike b : st.getBikeList()) {
			if(b.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
		
		assertTrue(freedSpaces == 9 && occupiedSpaces == 41 && 
				electricalBikes == 20 && mechanicalBikes == 21);
	}
	
	@Test
	void testHasAvailableElectricBikes() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		assertTrue(st.hasAvailableBikes("ELECTRICAL"));
	}
	
	@Test
	void testHasAvailableMechanicalBikes() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		assertTrue(st.hasAvailableBikes("MECHANICAL"));
	}
	
	@Test
	void testHasAvailableParkingSpaces() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		assertTrue(st.hasAvailableParkingSpaces());
	}
	
	@Test
	void testAddNewBycicleWhenVacancy() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		try {
			st.addNewBike("MECHANICAL");
		} catch (NoVacancyException e) {

		}
		
		@SuppressWarnings("unused")
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		for (Bike b : st.getBikeList()) {
			if(b.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
		assertTrue(mechanicalBikes == 22);
	}

	@Test
	void testAddNewBycicleNoVacancy() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 29; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		try {
			st.addNewBike("MECHANICAL");
		} catch (NoVacancyException e) {
		
		}
		
		@SuppressWarnings("unused")
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		for (Bike b : st.getBikeList()) {
			if(b.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
		assertTrue(mechanicalBikes == 21);
	}
	
	@Test
	void testRentBikeWhenAvailable() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		Bike b = null;
		
		try {
			b = st.rentBike("MECHANICAL");
		} catch (NoBikesAvailableException e) {
			
		}
		assertFalse(b == null);
		
		int freedSpaces = 0;
		int occupiedSpaces = 0;
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		
		for (ParkingSpace p : st.getParkingSpaces()) {
			if (p.isOccupied()) {
				occupiedSpaces += 1;
			}else {
				freedSpaces += 1;
			}
		}
		for (Bike b1 : st.getBikeList()) {
			if(b1.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b1.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
		
		assertTrue(freedSpaces == 10 && occupiedSpaces == 40 && 
				electricalBikes == 20 && mechanicalBikes == 20);
	}
	
	@Test
	void testRentBikeWhenNotAvailable() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		Bike b = null;
		
		try {
			b = st.rentBike("MECHANICAL");
		} catch (NoBikesAvailableException e) {
			assertTrue(true);
		}
		assertTrue(b == null);
		
		int freedSpaces = 0;
		int occupiedSpaces = 0;
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		
		for (ParkingSpace p : st.getParkingSpaces()) {
			if (p.isOccupied()) {
				occupiedSpaces += 1;
			}else {
				freedSpaces += 1;
			}
		}
		for (Bike b1 : st.getBikeList()) {
			if(b1.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b1.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
		
		assertTrue(freedSpaces == 30 && occupiedSpaces == 20 && 
				electricalBikes == 20 && mechanicalBikes == 0);
	}
	
	@Test
	void testReturnBikeVacancy() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		
		try {
			st.returnBike(new ElectricalBike());
		} catch (NoVacancyException e) {
			fail("Threw an exception when there was vacancy.");
		}
		
		int freedSpaces = 0;
		int occupiedSpaces = 0;
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		
		for (ParkingSpace p : st.getParkingSpaces()) {
			if (p.isOccupied()) {
				occupiedSpaces += 1;
			}else {
				freedSpaces += 1;
			}
		}
		for (Bike b1 : st.getBikeList()) {
			if(b1.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b1.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
	
		assertTrue(freedSpaces == 9 && occupiedSpaces == 41 && 
				electricalBikes == 21 && mechanicalBikes == 20);
		
	}
	
	@Test
	void testReturnBikeNoVacancy() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 25; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 25; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		try {
			st.returnBike(new ElectricalBike());
			fail("Didn't throw an exception");
		} catch (NoVacancyException e) {
			assertTrue(true);
		}
		
		int freedSpaces = 0;
		int occupiedSpaces = 0;
		int electricalBikes = 0;
		int mechanicalBikes = 0;
		
		for (ParkingSpace p : st.getParkingSpaces()) {
			if (p.isOccupied()) {
				occupiedSpaces += 1;
			}else {
				freedSpaces += 1;
			}
		}
		for (Bike b1 : st.getBikeList()) {
			if(b1.getBikeType().equalsIgnoreCase("ELECTRICAL")) {
				electricalBikes += 1;
			}else if(b1.getBikeType().equalsIgnoreCase("MECHANICAL")) {
				mechanicalBikes += 1;
			}
		}
	
		assertTrue(freedSpaces == 0 && occupiedSpaces == 50 && 
				electricalBikes == 25 && mechanicalBikes == 25);
	}
	

}
