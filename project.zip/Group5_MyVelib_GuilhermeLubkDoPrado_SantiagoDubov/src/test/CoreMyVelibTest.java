package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import myVelib.bikeFactory.BikeFactory;
import myVelib.bikeFactory.ElectricalBike;
import myVelib.bikeFactory.MechanicalBike;
import myVelib.core.CoreMyVelib;
import myVelib.coreAttributes.Station;
import myVelib.coreAttributes.User;
import myVelib.exceptions.BadBikeCreationException;
import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;
import myVelib.exceptions.NoVacancyException;
import myVelib.exceptions.StationHandlingException;
import myVelib.exceptions.UserHandlingException;
import myVelib.supportClasses.Coord;

class CoreMyVelibTest {

	@Test
	void testRentBike() {
		// tests that a user can successfully rent a bike at a station which has the required bike type
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
			User ur = core.getUserList().get(0);
			assertTrue(ur.getRentedBike() == null);
			core.addStation(new Coord(0,0), "standard", 10);
			Station st = core.getStationList().get(0);
			core.addBike(st.getStationID(), "Electrical");
			core.rentBike(ur.getUserID(), st.getStationID(), "Electrical", LocalDateTime.of(2020, 5, 3, 17, 30));
			assertFalse(ur.getRentedBike() == null);
		} catch (Exception e1) {
			System.out.println(1);
			fail();
			
		}
	}

	@Test
	void testReturnBike() {
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
			User ur = core.getUserList().get(0);
			ur.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
			core.addStation(new Coord(1,0), "standard", 10);
			Station st = core.getStationList().get(0);
			@SuppressWarnings("unused")
			BikeFactory bf = new BikeFactory();
			core.returnBike(ur.getUserID(), st.getStationID(), LocalDateTime.of(2020, 5, 3, 19, 30));
		} catch (UserHandlingException e) {
			// user has no bike therefore userhandling exception
		} catch (NoVacancyException e) {
			fail();
		} catch (EndTimeIsPriorToStartTimeSException e) {
			fail();
		} catch (StationHandlingException e) {
			fail();
		}
		
		try {
			//assuring that an exception is thrown if the end ride time is before the start ride time
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
			User ur = core.getUserList().get(0);
			ur.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
			core.addStation(new Coord(1,0), "standard", 10);
			Station st = core.getStationList().get(0);
			BikeFactory bf = new BikeFactory();
			ur.setRentedBike(bf.getBike("electrical"));
			core.updateUser(ur.getUserID(), st.getStationGPSLocation());
			core.returnBike(ur.getUserID(), st.getStationID(), LocalDateTime.of(2020, 5, 3, 15, 30));
		} catch (UserHandlingException e) {
			fail();
		} catch (NoVacancyException e) {
			fail();
		} catch (EndTimeIsPriorToStartTimeSException e) {
			// should throw this exception
		} catch (StationHandlingException e) {
			fail();
		} catch (BadBikeCreationException e) {
			fail();
		}
		
	}

	@Test
	void testAddUser() {
		CoreMyVelib core = new CoreMyVelib();

	
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
		} catch (Exception e1) {
			fail();
		}
		
		try {
			core.addUser("Paolo Ballarini", "supermaxicard", new Coord(0,0), "4560949568792058");
			fail();
		} catch (UserHandlingException e) {
		}
		
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "123");
			fail();
		} catch (UserHandlingException e) {
		}
		
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "fakenumberofleng");
			fail();
		} catch (UserHandlingException e) {
		}
		
		
	}

	@Test
	void testUpdateStation() {
		CoreMyVelib core = new CoreMyVelib();
		
		try {
			core.addStation(new Coord(0,0), "plus", 10);
			Station st = core.getStationList().get(0);
			assertTrue(core.getStation(st.getStationID()).isOnline());
			core.updateStation(st.getStationID(), false);
			assertFalse(core.getStation(st.getStationID()).isOnline());
			
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	void testAddStation() {
		// assures that a correct station type and a non-negative parking space number are entered
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addStation(new Coord(0,0), "plus", 10);
			core.addStation(new Coord(1,0), "standard", 10);
		} catch (StationHandlingException e) {
			fail();
		}
		
		try {
			core.addStation(new Coord(0,0), "non existant station type", 10);
			fail();
		} catch (StationHandlingException e) {
		}
		try {
			core.addStation(new Coord(0,0), "standard", -5);
			fail();
		} catch (StationHandlingException e) {
		}
		
	}

	@Test
	void testAddBike() {
		// Ensures that bikes are correctly added to stations and only if the station is not at full capacity
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addStation(new Coord(0,0), "plus", 2);
			core.addStation(new Coord(1,0), "standard", 10);
			Station st = core.getStationList().get(0);
			core.addBike(st.getStationID(), "electrical");
			core.addBike(st.getStationID(), "mechanical");
			assertTrue(core.getStation(st.getStationID()).getBikeList().get(0) instanceof ElectricalBike);
			assertTrue(core.getStation(st.getStationID()).getBikeList().get(1) instanceof MechanicalBike);
		} catch (Exception e) {
			fail();
		}
		
		CoreMyVelib core2 = new CoreMyVelib();
		try {
			core2.addStation(new Coord(1,1), "plus", 1);
			Station st = core2.getStationList().get(0);
			core2.addBike(st.getStationID(), "electrical");
			core2.addBike(st.getStationID(), "mechanical");
			fail();
		} catch (NoVacancyException e) {
		} catch (StationHandlingException e) {
			fail();
		}
	}


	@Test
	void testUpdateUser() {
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
			User ur = core.getUserList().get(0);
			assertTrue(core.getUser(ur.getUserID()).getUserGPSLocation().equals(new Coord(0,0)));
			core.updateUser(ur.getUserID(), new Coord(3,4));
			assertTrue(core.getUser(ur.getUserID()).getUserGPSLocation().equals(new Coord(3,4)));
			
		} catch (Exception e1) {
			fail();
		}
	}

	@Test
	void testDisplayUser() {
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addUser("Paolo Ballarini", "Vmax", new Coord(0,0), "4560949568792058");
			User ur = core.getUserList().get(0);
			core.displayUser(ur.getUserID());
			
		} catch (Exception e1) {
			fail();
		}
	}

	@Test
	void testPlanRide() {
		// correct answer should be go to (1,1) and finish at (4,4)
		CoreMyVelib core = new CoreMyVelib();
		try {
			core.addStation(new Coord(1,1), "plus", 2);
			Station st = core.getStationList().get(0);
			st.addNewBike("electrical");
			core.addStation(new Coord(1,0), "standard", 10);
			core.addStation(new Coord(5,4), "plus", 1);
			Station st3 = core.getStationList().get(2);
			st3.addNewBike("mechanical");
			core.addStation(new Coord(4,4), "standard", 10);
			core.planRide(new Coord(0,0), new Coord(5,5), "Electrical", "standard");
			
			
		} catch (Exception e1) {
			fail();
		}
	}

}
