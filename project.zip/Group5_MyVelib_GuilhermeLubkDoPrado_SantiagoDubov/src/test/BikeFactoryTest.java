package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import myVelib.bikeFactory.Bike;
import myVelib.bikeFactory.BikeFactory;
import myVelib.bikeFactory.ElectricalBike;
import myVelib.bikeFactory.MechanicalBike;
import myVelib.exceptions.BadBikeCreationException;

class BikeFactoryTest {

	@Test
	void testGetElectricalBike() {
		BikeFactory bf = new BikeFactory();
		try {
			Bike bike = bf.getBike("ElEcTrIcAl");
			assertTrue(bike instanceof ElectricalBike);
		} catch (BadBikeCreationException e) {
			System.out.println("The biketype does not exist: " + e.getBikeType());
		}
	}
	
	@Test
	void testGetMechanicalBike() {
		BikeFactory bf = new BikeFactory();
		try {
			Bike bike = bf.getBike("MeChAnIcAl");
			assertTrue(bike instanceof MechanicalBike);
		} catch (BadBikeCreationException e) {
			System.out.println("The biketype does not exist: " + e.getBikeType());
		}
	}
	
	@Test
	void testMispelledBikeType() {
		BikeFactory bf = new BikeFactory();
		try {
			Bike bike = bf.getBike("Motorcycle");
			if(bike instanceof Bike) {
				fail("Didn't throw the exception");
			}
		} catch (BadBikeCreationException e) {
			assertTrue(true);
		}
	}

}