package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import myVelib.coreAttributes.ParkingSpace;

class ParkingSpaceTest {

	@Test
	void testUniqueSerials() {
		ParkingSpace p1 = new ParkingSpace();
		ParkingSpace p2 = new ParkingSpace();
		assertFalse(p1.getParkingSpaceID() == p2.getParkingSpaceID());
	}
	
	@Test
	void testOccupationAndOperationAtCreation() {
		ParkingSpace p1 = new ParkingSpace();
		assertTrue(p1.isOnline() == true);
		assertTrue(p1.isOccupied() == false);	
	}
}
