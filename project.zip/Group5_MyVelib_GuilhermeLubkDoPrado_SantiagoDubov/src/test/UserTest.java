package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import myVelib.coreAttributes.User;
import myVelib.observersReports.UserReport;
import myVelib.supportClasses.Coord;

class UserTest {

	@Test
	void testAddTotalCharges() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		
		ur.addUser(u);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u.addTotalCharges(4);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u.addTotalCharges(2);
		assertTrue(u.getTotalCharges() == 6);
	}
	
	@Test
	void testAddTimeBalance() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		
		ur.addUser(u);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(4);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(2);
		assertTrue(u.getTimeBalance() == 10);
	}

}
