package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import myVelib.bikeFactory.Bike;
import myVelib.bikeFactory.MechanicalBike;
import myVelib.coreAttributes.Station;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.observersReports.StationReport;
import myVelib.supportClasses.Coord;

class StationReportTest {

	@Test
	void testStatsInitialization() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		assertTrue( sr.getNumberRents(st.getStationID()) == 0 && sr.getNumberReturns(st.getStationID()) == 0
				&& sr.getNumberOfBikes(st.getStationID()) == 41 && sr.getNumberOfSpaces(st.getStationID()) == 50 && sr.getOccupation(st.getStationID()) == 41.0/50.0 );
	}
	
	@Test
	void testStatsAddedBike() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		
		try {
			st.addNewBike("MECHANICAL");
		} catch (NoVacancyException e) {
			fail("Threw exception");
		}
		
		assertTrue( sr.getNumberRents(st.getStationID()) == 0 && sr.getNumberReturns(st.getStationID()) == 0
				&& sr.getNumberOfBikes(st.getStationID()) == 42 && sr.getNumberOfSpaces(st.getStationID()) == 50 && sr.getOccupation(st.getStationID()) == 42.0/50.0);
	}
	
	@Test
	void testStatsRentedBike() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		@SuppressWarnings("unused")
		Bike b = null;
		
		try {
			b = st.rentBike("ELECTRICAL");
			b = st.rentBike("ELECTRICAL");
			b = st.rentBike("MECHANICAL");
		} catch (NoBikesAvailableException e) {
			fail("Threw exception");
		}
		
		assertTrue( sr.getNumberRents(st.getStationID()) == 3 && sr.getNumberReturns(st.getStationID()) == 0
				&& sr.getNumberOfBikes(st.getStationID()) == 38 && sr.getNumberOfSpaces(st.getStationID()) == 50 && sr.getOccupation(st.getStationID()) == 38.0/50.0);
	}
	
	
	@Test
	void testStatsReturnedBike() {
		Station st = new Station(new Coord(25, 25), "plus", 50);
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		@SuppressWarnings("unused")
		Bike b = null;
		
		try {
			b = st.rentBike("ELECTRICAL");
			b = st.rentBike("ELECTRICAL");
			b = st.rentBike("MECHANICAL");
		} catch (NoBikesAvailableException e) {
			fail("Threw exception NoBikesAvailableException");
		}
		
		try {
			st.returnBike(b);
			st.returnBike(new MechanicalBike());
		} catch (NoVacancyException e) {
			fail("Threw NoVacancyException");
		}
		
		
		assertTrue( sr.getNumberRents(st.getStationID()) == 3 && sr.getNumberReturns(st.getStationID()) == 2
				&& sr.getNumberOfBikes(st.getStationID()) == 40 && sr.getNumberOfSpaces(st.getStationID()) == 50 && sr.getOccupation(st.getStationID()) == 40.0/50.0);
	}
	
	@Test
	void testSortedStations() {
		Station st = new Station(new Coord(0, 0), "plus", 50);
		Station st1 = new Station(new Coord(1, 1), "plus", 50);
		Station st2 = new Station(new Coord(2, 2), "plus", 50);
		
		StationReport sr = new StationReport();
		st.attach(sr);
		sr.addStation(st);
		sr.addStation(st1);
		sr.addStation(st2);
		st1.attach(sr);
		st2.attach(sr);
		
		//Populate it with i electrical bikes
		for (int i = 0; i < 20; i++) {
			try {
				st.addNewBike("ELECTRICAL");
				st2.addNewBike("electrical");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		//Populate it with i mechanical bikes
		for (int i = 0; i < 21; i++) {
			try {
				st.addNewBike("MECHANICAL");
			} catch (NoVacancyException e) {
				fail("Threw exception");
			}
		}
		
		@SuppressWarnings("unused")
		Bike b = null;
		
		try {
			b = st.rentBike("ELECTRICAL");
			b = st.rentBike("ELECTRICAL");
			b = st.rentBike("MECHANICAL");
			b = st2.rentBike("electrical");
		} catch (NoBikesAvailableException e) {
			fail("Threw exception NoBikesAvailableException");
		}
		
		try {
			st1.returnBike(b);
			st1.returnBike(new MechanicalBike());
		} catch (NoVacancyException e) {
			fail("Threw NoVacancyException");
		}
		
		try {
			ArrayList<Station> sorted_stations_by_usage = sr.getSortedStations("mostUsed");
			assertTrue(sorted_stations_by_usage.get(0).equals(st));
			assertTrue(sorted_stations_by_usage.get(1).equals(st1));
			assertTrue(sorted_stations_by_usage.get(2).equals(st2));
			
			ArrayList<Station> sorted_stations_by_occupancy = sr.getSortedStations("mostOccupied");
			assertTrue(sorted_stations_by_occupancy.get(0).equals(st));
			assertTrue(sorted_stations_by_occupancy.get(1).equals(st2));
			assertTrue(sorted_stations_by_occupancy.get(2).equals(st1));
			
		
		} catch (UnknownOperationTypeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
