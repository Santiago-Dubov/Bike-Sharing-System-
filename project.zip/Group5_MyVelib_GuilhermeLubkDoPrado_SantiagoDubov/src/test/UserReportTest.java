package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import myVelib.coreAttributes.User;
import myVelib.observersReports.UserReport;
import myVelib.supportClasses.Coord;

class UserReportTest {

	@Test
	void testTotalChargesData() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		
		ur.addUser(u);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u.addTotalCharges(4);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u.addTotalCharges(2);
		assertTrue(ur.getTotalCharges(u.getUserID()) == 6);
	}
	
	@Test
	void testTotalTimeCreditData() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		
		ur.addUser(u);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(4);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(2);
		assertTrue(ur.getTotalTimeCredit(u.getUserID()) == 10);
	}
	
	@Test
	void testTotalTimeOnBikeData() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		
		ur.addUser(u);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(4);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(2);
		assertTrue(ur.getTimeOnBike(u.getUserID()) == 44);
	}
	
	@Test
	void testNumberOfRidesData() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		
		ur.addUser(u);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(4);
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u.addTimeBalance(5);
		u.addTotalCharges(2);
		//2 rides expected
		assertTrue(ur.getNumberOfRides(u.getUserID()) == 2);
	}
	
	@Test
	void testMultipleUsers() {
		UserReport ur = new UserReport();
		User u = new User("Santiago", "none", new Coord(5, 15), "5555444455554444", ur);
		User u1 = new User("Guilherme", "none", new Coord(15, 5), "5555444455554444", ur);
		
		ur.addUser(u);
		ur.addUser(u1);
		
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 30));
		u1.setInitialRentTime(LocalDateTime.of(2020, 5, 3, 17, 00));
		
		u.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		u1.setEndRentTime(LocalDateTime.of(2020, 5, 3, 17, 37));
		
		u.addTimeBalance(5);
		u.addTotalCharges(4);
		u1.addTimeBalance(5);
		u1.addTotalCharges(6);
		
		
		u.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 12, 00));
		u1.setInitialRentTime(LocalDateTime.of(2020, 5, 4, 11, 00));
		
		u.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		u1.setEndRentTime(LocalDateTime.of(2020, 5, 4, 12, 37));
		
		u.addTimeBalance(5);
		u.addTotalCharges(2);
		u1.addTimeBalance(5);
		u1.addTotalCharges(1);
		
		//2 rides expected
		assertTrue(ur.getNumberOfRides(u1.getUserID()) == 2
				&& ur.getTotalTimeCredit(u1.getUserID()) == 10
				&& ur.getTotalCharges(u1.getUserID()) == 7
				&& ur.getTimeOnBike(u1.getUserID()) == 134);
	}
	

}
