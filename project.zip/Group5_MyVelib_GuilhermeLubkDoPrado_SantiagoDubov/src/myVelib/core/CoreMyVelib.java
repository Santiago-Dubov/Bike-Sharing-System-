package myVelib.core;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import myVelib.coreAttributes.Station;
import myVelib.coreAttributes.User;
import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.exceptions.StationHandlingException;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.exceptions.UnknownPolicyException;
import myVelib.exceptions.UserHandlingException;
import myVelib.observersReports.StationReport;
import myVelib.observersReports.UserReport;
import myVelib.pricingCalculator.PricingCalculator;
import myVelib.ridePlanner.RidePlanner;
import myVelib.supportClasses.Coord;
import myVelib.supportClasses.SerialNumberGenerator;

/**
 * CoreMyVelib
 * 
 * Class responsible for realizing all the operations of the myVelib system demanded by the user through the CLUI.
 * <p>Users and Stations are stored in HashTables and have their ID numbers as keys.
 * <p>All the thrown exceptions are handled with a message being printed in the console.
 * <p>This class implements java.io.Serializable. 
 * 
 */

public class CoreMyVelib implements java.io.Serializable{
	private static final long serialVersionUID = -5128567448646502924L;
	//Core attributes
	private Map<Integer, Station> stationList;
	private Map<Integer, User> userList;
	private UserReport userReport;
	private StationReport stationReport;
	private int IDstate;
	
	public CoreMyVelib() {
		this.userReport = new UserReport();
		this.stationReport = new StationReport();
		this.userList = new HashMap<Integer, User>();
		this.stationList = new HashMap<Integer, Station>();	
	}
	
	public void rentBike(int userID, int stationID, String bikeType, LocalDateTime time) throws NoBikesAvailableException, UserHandlingException, StationHandlingException{
		Station st = stationList.get(stationID);
        User ur = userList.get(userID);
        if (!st.isOnline()) {
            throw new StationHandlingException();
        }
        else if (ur.getUserGPSLocation().equals(st.getStationGPSLocation())){
            ur.setRentedBike(st.rentBike(bikeType));
            ur.setInitialRentTime(time);
        }
        else {
            throw new UserHandlingException();
        }
	}
	
	public void returnBike(int userID, int stationID, LocalDateTime time) throws NoVacancyException, EndTimeIsPriorToStartTimeSException, UserHandlingException {
		Station st = stationList.get(stationID);
		User ur = userList.get(userID);
		if (ur.getRentedBike() == null) {
			throw new UserHandlingException();
		}
		if (ur.getUserGPSLocation().equals(st.getStationGPSLocation())){
			String bikeType = ur.getRentedBike().getBikeType();
			if (ur.getInitialRentTime().isAfter(time)) {
				throw new EndTimeIsPriorToStartTimeSException();
			}
			
			st.returnBike(ur.getRentedBike());
			ur.setRentedBike(null);
			ur.setEndRentTime(time);
			this.updateUser(ur.getUserID(), st.getStationGPSLocation());
			PricingCalculator pc = new PricingCalculator(bikeType);
			pc.displayPrice(ur, st.getStationType());
		}else {
			throw new UserHandlingException();
		}
	}
	
	public void addUser(String userName, String cardType, Coord locationGPS, String creditCardNumber) throws UserHandlingException{
		if (! (cardType.equalsIgnoreCase("Vlibre") | cardType.equalsIgnoreCase("Vmax") | cardType.equalsIgnoreCase("none"))) {
			throw new UserHandlingException();
		}
	
		else if (creditCardNumber.length() != 16 | !creditCardNumber.chars().allMatch( Character::isDigit )) {
			throw new UserHandlingException();
		}
		
		else {
			User u1 = new User(userName, cardType, locationGPS, creditCardNumber, this.userReport);
			userReport.addUser(u1);
			userList.put(u1.getUserID(), u1);
			IDstate = SerialNumberGenerator.getInstance().getSerialNumber();
		}
		
	}
	
	public void updateStation(int stationID, Boolean isOnline) {
		Station st = stationList.get(stationID);
		st.setOnline(isOnline);
	}
	
	public void updateStation(int stationID, String stationType) throws StationHandlingException {
		Station st = stationList.get(stationID);
		if (! (stationType.equalsIgnoreCase("standard") | stationType.equalsIgnoreCase("plus"))) {
			throw new StationHandlingException();
		}else {
			st.setStationType(stationType);
		}
		
	}
	
	public void addStation(Coord stationGPSLocation, String stationType, int nSpaces) throws StationHandlingException{
		if (! (stationType.equalsIgnoreCase("standard") | stationType.equalsIgnoreCase("plus"))) {
			throw new StationHandlingException();
		}else if(nSpaces <= 0) {
			throw new StationHandlingException();
		}else {
			Station st = new Station(stationGPSLocation, stationType, nSpaces);
			st.attach(this.stationReport);
			this.stationReport.addStation(st);
			stationList.put(st.getStationID(), st);
			IDstate = SerialNumberGenerator.getInstance().getSerialNumber();
		}
	}
	
	public void addBike( int stationID, String bikeType) throws NoVacancyException{
		Station st = stationList.get(stationID);
		st.addNewBike(bikeType);
		IDstate = SerialNumberGenerator.getInstance().getSerialNumber();
	}
	
	public void displaySortedStations(String sortPolicy) throws UnknownOperationTypeException{
		ArrayList<Station> stlst = stationReport.getSortedStations(sortPolicy);
		for (Station st : stlst) {
			int freeSpaces = st.getParkingSpaces().size() - st.getBikeList().size();
			System.out.println("ID: " + st.getStationID() + ", Location: " + st.getStationGPSLocation() + ", Online: " + st.isOnline() + ", Free Spaces: " + freeSpaces + 
			", Occupied Spaces: " + (st.getParkingSpaces().size() - freeSpaces) + ", Type: " + st.getStationType()+ ", Total rents: " + this.stationReport.getNumberRents(st.getStationID()) + ", Total returns: " + 
					this.stationReport.getNumberReturns(st.getStationID()));
		}
	}
	
	public void updateUser( int userID, Coord GPSLocation) throws UserHandlingException {
		if(userList.containsKey(userID)) {
			User ur = userList.get(userID);
			ur.setUserGPSLocation(GPSLocation);
		}else {
			throw new UserHandlingException();
		}
	}
	
	public void displayStation(int stationID) throws StationHandlingException {
		//Displays various information about a given station
		if(stationList.containsKey(stationID)) {
			Station st = stationList.get(stationID);
			int freeSpaces = st.getParkingSpaces().size() - st.getBikeList().size();
			System.out.println("ID: " + stationID + ", Location: " + st.getStationGPSLocation() + ", Online: " + st.isOnline() + ", Free Spaces: " + freeSpaces + 
			", Occupied Spaces: " + (st.getParkingSpaces().size() - freeSpaces) + ", Type: " + st.getStationType() + ", Total rents: " + this.stationReport.getNumberRents(stationID) + ", Total returns: " + this.stationReport.getNumberReturns(stationID)
			 );
		}else {
			throw new StationHandlingException();
		}
	}
	
	public void displayUser(int userID) throws UserHandlingException {
		if(userList.containsKey(userID)) {
			User ur = userList.get(userID);
			System.out.println("ID: " + userID + ", Name: " + ur.getName() + ", Location" + ur.getUserGPSLocation() + ", Time credit: " + userReport.getTotalTimeCredit(userID) +
			", Number of Rides: " + userReport.getNumberOfRides(userID) + ", Total bike time (minutes): " + userReport.getTimeOnBike(userID));
		}else {
			throw new UserHandlingException();
		}
	}
	public void planRide( Coord initialGPSLocation, Coord endGPSLocation, String bikeType, String ridePolicy) {
		
		try {
			RidePlanner rideplanner = new RidePlanner(ridePolicy);
			rideplanner.printPlanning(initialGPSLocation, endGPSLocation, bikeType, this.getStationList());
		} catch (UnknownPolicyException e) {
			System.err.println("Unknown policy when planning a ride");
		}
	}
	
	public Set<Integer> getStationsID(){
		return stationList.keySet();
	}
	
	public Station getStation(int stationID){
		return this.stationList.get(stationID);
	}
	
	public ArrayList<Station> getStationList() {
		return new ArrayList<>(Arrays.asList(this.stationList.values().toArray(new Station[0])));
	}
	
	public ArrayList<User> getUserList(){
		return new ArrayList<>(Arrays.asList(this.userList.values().toArray(new User[0])));
	}
	
	public User getUser(int userID) {
		return this.userList.get(userID);
	}
	
	public void displayAllStations() {
		for (Station station : this.getStationList()) {
			try {
				this.displayStation(station.getStationID());
			} catch (StationHandlingException e) {
				
			}
		}
	}
	
	public void displayAllUsers() {
		for (User user: this.getUserList()) {
			try {
				this.displayUser(user.getUserID());
			} catch (UserHandlingException e) {

			}
		}
	}
	
	public Station getStationByLocation(Coord location) throws StationHandlingException{
		for (Station station : this.getStationList()) {
			if (location.equals(station.getStationGPSLocation())) {
				return station;	
			}
		}
		throw new StationHandlingException();
	}
	
	public User getUserByCreditCard(String creditCard) throws UserHandlingException {
		for(User user : this.getUserList()) {
			if(user.getCreditCard().equalsIgnoreCase(creditCard)){
				return user;
			}
		}
		throw new UserHandlingException();
	}
	
	public int getTotalNumberOfBikes() {
		int num = 0;
		for (Station station : this.getStationList()) {
			num += station.getBikeList().size();
		}
		return num;
	}
	
	public void recoverIDState() {
		SerialNumberGenerator.getInstance().recoverID(IDstate);
	}

}
