package myVelib.supportClasses;

/** 
 * SerialNumberGenerator class
 * Used to produce a unique serial number for each bike, station, user and parking space. 
 * This is done according to the singleton pattern
 */
public class SerialNumberGenerator implements java.io.Serializable{

	private static final long serialVersionUID = 7698465140307719256L;
	private static SerialNumberGenerator instance = null;
	private int num;
	
	//Constructor is private, can only be called from getInstance()
	private SerialNumberGenerator() {
		this.num = 0;
	}
	
	//Ensures the use of the same instance of this class
	public static SerialNumberGenerator getInstance() {
		if (instance == null) {
			instance = new SerialNumberGenerator();
		}
		return instance;
	}
	
	//Returns the next serial number, different from the previous one
	public int getNextSerialNumber() {
		return num ++;
	}
	
	public int getSerialNumber() {
		return num;
	}
	
	public void recoverID(int num) {
		this.num = num;
	}

}
