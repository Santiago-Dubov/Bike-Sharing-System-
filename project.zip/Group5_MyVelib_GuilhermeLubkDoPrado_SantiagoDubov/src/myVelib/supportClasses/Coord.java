package myVelib.supportClasses;

import java.awt.geom.Point2D;

/**
 * Coord class
 * This class is an extension of java.awt.geom.Point2D with an overwritten
 * toString method. 
 *<p>getY() and getX() are the used methods we have interest from the super class.
 *
 */
public class Coord extends Point2D.Double implements java.io.Serializable{
	private static final long serialVersionUID = 2603526979101903960L;

	public Coord() {
	}

	public Coord(double x, double y) {
		super(x, y);
	}

	@Override
	public String toString() {
		return "[" + x + "," + y + "]";
	}

}
