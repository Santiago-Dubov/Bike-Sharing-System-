package myVelib.supportClasses;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;

/**
 *DifferenceInMinutes class
 *<p>This class has only a single static method that returns the amount of time,
 *in minutes, that has been passed since an initial start time. If the start time is
 *prior to the end time, it will throw an exception (EndTimeIsPriorToStartTimeSException)
 */
public class DifferenceInMinutes implements java.io.Serializable {

	private static final long serialVersionUID = 3010217461491897945L;

	public static int returnDifferenceInMinutes(LocalDateTime startTime, LocalDateTime endTime) throws EndTimeIsPriorToStartTimeSException{
		if(!(endTime.isAfter(startTime))) {
			throw new EndTimeIsPriorToStartTimeSException();
		}else {
			int deltaMinutes = (int) startTime.until(endTime, ChronoUnit.MINUTES);			
			return deltaMinutes;
		}
	}

}
