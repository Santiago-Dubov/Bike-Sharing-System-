package myVelib.pricingCalculator;

import myVelib.coreAttributes.User;

public class PricingCalculator implements java.io.Serializable {

	private static final long serialVersionUID = 8167678764172571172L;
	private CalculateStrategy calculationStrategy;
	
	public PricingCalculator(String bikeType) {
		super();
		if(bikeType.equalsIgnoreCase("ELECTRICAL")) {
			calculationStrategy = new CalculateCostElectricalBike();
		}else if(bikeType.equalsIgnoreCase("MECHANICAL")) {
			calculationStrategy = new CalculateCostMechanicalBike();
		}
	}
	
	public void displayPrice(User user, String stationType) {
		int charge = calculationStrategy.calculatePrice(user);
		user.addTotalCharges(charge);

		if(user.getCardType().equalsIgnoreCase("Vlib") | user.getCardType().equalsIgnoreCase("Vmax")) {
			if(stationType.equalsIgnoreCase("plus")) {
				user.addTimeBalance(5);
			}
		}
		
		System.out.println("Amount charged to user's credit card for the ride: " + charge + " Euro(s).");
	}

}
