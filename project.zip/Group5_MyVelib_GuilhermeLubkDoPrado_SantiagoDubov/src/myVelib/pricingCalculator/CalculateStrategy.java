package myVelib.pricingCalculator;

import myVelib.coreAttributes.User;

public interface CalculateStrategy {
	
	public int calculatePrice(User user);
}
