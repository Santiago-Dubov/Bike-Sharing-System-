package myVelib.pricingCalculator;

import myVelib.coreAttributes.User;
import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;
import myVelib.supportClasses.DifferenceInMinutes;

public class CalculateCostElectricalBike implements CalculateStrategy, java.io.Serializable{

	private static final long serialVersionUID = 5021245027301454580L;

	public CalculateCostElectricalBike() {
		super();
	}
	
	@Override
	public int calculatePrice(User user) {
		try {
			int rideDuration = DifferenceInMinutes.returnDifferenceInMinutes(user.getInitialRentTime(), user.getEndRentTime());
			int costElectrical = 2;
			
			if(user.getCardType().equalsIgnoreCase("none")) {
				return (int) (Math.floor(rideDuration/60) + 1)*costElectrical;
			
			}else if(user.getCardType().equalsIgnoreCase("Vlibre")) {	
				if(rideDuration > 60) {
					if(user.getTimeBalance() < (rideDuration-60)) {
						int timeBalance = user.getTimeBalance();
						user.setTimeBalance(0);
						return (int) (1 + (Math.floor((rideDuration-timeBalance)/60))*costElectrical);
					}else {
						int timeBalance = user.getTimeBalance();
						user.setTimeBalance(timeBalance - (rideDuration-60));
						return 1;
					}
				}else {
					return 1;
				}
			
			}else if(user.getCardType().equalsIgnoreCase("Vmax")) {
				if(rideDuration > 60) {
					if(user.getTimeBalance() < (rideDuration-60)) {
						int timeBalance = user.getTimeBalance();
						user.setTimeBalance(0);
						return (int) (Math.floor((rideDuration-timeBalance)/60))*(costElectrical-1);
					}else {
						int timeBalance = user.getTimeBalance();
						user.setTimeBalance(timeBalance - (rideDuration-60));
						return 0;
					}
				}else {
					return 0;
				}
				
			}
		} catch (EndTimeIsPriorToStartTimeSException e) {
			System.err.println("Couldn't calculate cost. End time for the ride is prior to its start time.");
		}
		return 0;
	}

}
