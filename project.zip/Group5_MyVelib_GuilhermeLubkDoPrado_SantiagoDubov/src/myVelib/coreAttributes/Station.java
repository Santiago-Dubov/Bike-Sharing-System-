package myVelib.coreAttributes;

import java.util.ArrayList;

import myVelib.bikeFactory.Bike;
import myVelib.bikeFactory.BikeFactory;
import myVelib.exceptions.BadBikeCreationException;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.observersReports.Observable;
import myVelib.observersReports.Observer;
import myVelib.supportClasses.Coord;
import myVelib.supportClasses.SerialNumberGenerator;

/**
 * Station
 *<p>Class used to represent a myVelib station. In this current version
 *a station cannot be expanded nor reduced. Also, parking spaces are set
 *offline when the station is offline. This simplification is far from ideal was made to allow the
 *correct conclusion and test of an initial version of the project and will be updated
 *if we can save some spare time.
 *<p>Also, there's no association between bike-parking space in this version. The user returns the
 *bike to the station and the station allocates the bike in any available parking space. This is far from
 *ideal, because in real life the user would return the bike in some parking space of his preference. We hope
 *to improve that if we can, but we prioritize the delivery of a well tested and documented version of the
 *project first.
 *
 */
public class Station implements Observable, java.io.Serializable{
	
	private static final long serialVersionUID = -3548950441676793620L;
	private Coord stationGPSLocation;
	private int stationID;
	private ArrayList<Bike> bikeList;
	private ArrayList<ParkingSpace> parkingSpaces;
	private BikeFactory bikeFactory;
	private boolean isOnline;
	private String stationType;
	private Observer stationReport;
	
	public Station(Coord stationGPSLocation, String stationType, int nSpaces) {
		// Used to create a station, the parking spaces and bikes
		bikeList = new ArrayList<Bike>();
		parkingSpaces = new ArrayList<ParkingSpace>();
		bikeFactory = new BikeFactory();
		
		SerialNumberGenerator sng = SerialNumberGenerator.getInstance();
		this.stationID = sng.getNextSerialNumber();
		this.stationGPSLocation = stationGPSLocation;
		this.isOnline = true;
		this.stationType = stationType;
		
		for (int i = 0; i < nSpaces; i++) {
			this.parkingSpaces.add(new ParkingSpace());
		}

	}

	public boolean hasAvailableBikes(String bikeType) {
		for (Bike bike : this.bikeList) {
			if (bike.getBikeType().equalsIgnoreCase(bikeType)) {
				return true;
            }
		}
		return false;
	}
	
	public boolean hasAvailableParkingSpaces() {
		for (ParkingSpace p : this.parkingSpaces) {
			if(p.isOccupied() == false) {
				return true;
			}
		}
		return false;
	}
	
	//This method will add a new bike and set a parking space as occupied if
	//	any is available
	public void addNewBike(String bikeType) throws NoVacancyException{
		if(this.hasAvailableParkingSpaces()) {
			try {
				Bike b = bikeFactory.getBike(bikeType);
				bikeList.add(b);
				this.occupyParkingSpace();
				this.updateObserver("addedNewBike");
			} catch (BadBikeCreationException e) {
				System.err.println("Unknown bike type when trying to add a new bike to the station " + this.stationID);
			}
		}else {
			throw new NoVacancyException();
		}
	}
	
	//This method will remove a bike from the station, freed a parking space
	//	and return the bike to the user (as long as he is using the bike, his
	//	bike pointer will be non null)
	public Bike rentBike(String bikeType) throws NoBikesAvailableException{
		if(this.hasAvailableBikes(bikeType)) {
			for(Bike b : bikeList) {
				if(b.getBikeType().equalsIgnoreCase(bikeType)) {
					bikeList.remove(b);
					this.emptyParkingSpace();
					this.updateObserver("rent");
					return b;
				}
			}
			throw new NoBikesAvailableException();
		}else {
			throw new NoBikesAvailableException();
		}
	}
	
	//This method will remove a bike from the station, freed a parking space
	//	and return the bike to the user (as long as he is using the bike, his
	//	bike pointer will be non null)
	private void emptyParkingSpace() {
		for(ParkingSpace p : parkingSpaces) {
			if(p.isOccupied()) {
				p.setOccupied(false);
				break;
			}
		}
	}

	//This method will return a bike to the station and occupy a parking
	//	space. If no errors are thrown, the core will remove the bike from 
	//	the user.
	public void returnBike(Bike bike) throws NoVacancyException{
		if(this.hasAvailableParkingSpaces()) {
			this.bikeList.add(bike);
			this.occupyParkingSpace();
			this.updateObserver("return");
		}else {
			throw new NoVacancyException();
		}
	}
	
	//This method will occupy a parking space, representing the addition or
	//	return of a bike
	private void occupyParkingSpace(){
		for(ParkingSpace p : parkingSpaces) {
			if(p.isOccupied() == false) {
				p.setOccupied(true);
				break;
			}
		}
	}
	
	public Coord getStationGPSLocation() {
		return stationGPSLocation;
	}
	
	public void setStationGPSLocation(Coord stationGPSLocation) {
		this.stationGPSLocation = stationGPSLocation;
	}
	
	public int getStationID() {
		return stationID;
	}

	public ArrayList<Bike> getBikeList() {
		return bikeList;
	}

	public boolean isOnline() {
		return isOnline;
	}

	public void setOnline(boolean isOnline) {
		this.isOnline = isOnline;
	}

	public String getStationType() {
		return stationType;
	}

	public void setStationType(String stationType) {
		this.stationType = stationType;
	}

	@Override
	public String toString() {
		int freeSpaces = this.getParkingSpaces().size()-this.getBikeList().size();
		return "Station [stationGPSLocation=" + stationGPSLocation + ", stationID=" + ", isOnline=" + isOnline + ", stationType="
				+ stationType + ", Free Spaces: " + freeSpaces + "]";
	}

	public ArrayList<ParkingSpace> getParkingSpaces() {
		return parkingSpaces;
	}

	@Override
	public void attach(Observer observer) {
		this.stationReport = observer;
	}

	@Override
	public void detach(Observer observer) {
		this.stationReport = null;
	}

	@Override
	public void updateObserver(String operationType) {
		try {
			stationReport.update(this.stationID, operationType);
		} catch (UnknownOperationTypeException e) {
			System.err.println("Unknown operation type while updating the stations report");
		}
		
	}

}
