package myVelib.coreAttributes;

import myVelib.supportClasses.SerialNumberGenerator;

/**
 * ParkingSpace class
 * <p>This class contains its unique ID and two boolean attributes to determinate
 * if the space is occupied and operational or not.
 * <p>In this version its impossible to associate a Bike to a ParkingSpace
 * directly through this class.
 */
public class ParkingSpace implements java.io.Serializable{

	private static final long serialVersionUID = -3653054851147459518L;
	private int parkingSpaceID;
	private boolean isOccupied;
	private boolean isOnline;
	
	public ParkingSpace() {
		super();
		SerialNumberGenerator sng = SerialNumberGenerator.getInstance();
		this.parkingSpaceID = sng.getNextSerialNumber();
		this.isOccupied = false;
		this.isOnline = true;
	}

	public boolean isOccupied() {
		return isOccupied;
	}

	public void setOccupied(boolean isOccupied) {
		this.isOccupied = isOccupied;
	}

	public boolean isOnline() {
		return isOnline;
	}

	public void setOnline(boolean isOnline) {
		this.isOnline = isOnline;
	}

	public int getParkingSpaceID() {
		return parkingSpaceID;
	}

	@Override
	public String toString() {
		return "ParkingSpace [parkingSpaceID=" + parkingSpaceID + ", isOccupied=" + isOccupied + ", isOnline="
				+ isOnline + "]";
	}
	
}
