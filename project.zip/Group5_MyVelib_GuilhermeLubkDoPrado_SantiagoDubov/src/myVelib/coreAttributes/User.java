package myVelib.coreAttributes;

import java.time.LocalDateTime;

import myVelib.bikeFactory.Bike;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.observersReports.Observable;
import myVelib.observersReports.Observer;
import myVelib.supportClasses.Coord;
import myVelib.supportClasses.SerialNumberGenerator;

/**
 *User class
 *<p>The user class contains all the necessary attributes to store information about an user (unique ID,
 *name, credit card and vlib card) and all the relevant informations of it's previous ride (the rented bike, 
 *the start time and the end time of the rent). This information is used to update the user report and 
 *calculate the last ride's fare.
 *<p>This version of user it's not updatable. That means that only the GPS position of an user can be changed.
 *This is done in order to keep consistency with the available functions in the core and in the CLUI.
 */


public class User implements Observable, java.io.Serializable{

	private static final long serialVersionUID = 3380328401450380861L;
	private int userID;
	private String name;
	private String cardType;
	private Coord userGPSLocation;
	private String creditCard;
	private int timeBalance;
	private int totalCharges;
	private Bike rentedBike;
	private LocalDateTime initialRentTime;
	private LocalDateTime endRentTime;
	private Observer userReport;
	
	public User(String name, String cardType, Coord userGPSLocation, String creditCard, Observer observer) {
		super();
		SerialNumberGenerator sng = SerialNumberGenerator.getInstance();
		this.userID = sng.getNextSerialNumber();
		this.name = name;
		this.cardType = cardType;
		this.userGPSLocation = userGPSLocation;
		this.creditCard = creditCard;
		this.timeBalance = 0;
		this.totalCharges = 0;
		this.rentedBike = null;
		this.initialRentTime = null;
		this.endRentTime = null;
		attach(observer);
	}
	
	public String getCardType() {
		return cardType;
	}

	public Coord getUserGPSLocation() {
		return userGPSLocation;
	}

	public void setUserGPSLocation(Coord userGPSLocation) {
		this.userGPSLocation = userGPSLocation;
	}

	public String getCreditCard() {
		return creditCard;
	}

	public int getTimeBalance() {
		return timeBalance;
	}
	
	public void setTimeBalance(int timeBalance) {
		this.timeBalance = timeBalance;
	}

	public Bike getRentedBike() {
		return rentedBike;
	}

	public void setRentedBike(Bike rentedBike) {
		this.rentedBike = rentedBike;
	}

	public LocalDateTime getInitialRentTime() {
		return initialRentTime;
	}

	public void setInitialRentTime(LocalDateTime initialRentTime) {
		this.initialRentTime = initialRentTime;
	}

	public LocalDateTime getEndRentTime() {
		return endRentTime;
	}

	public void setEndRentTime(LocalDateTime endRentTime) {
		this.endRentTime = endRentTime;
	}

	public int getUserID() {
		return userID;
	}

	public String getName() {
		return name;
	}

	public int getTotalCharges() {
		return totalCharges;
	}
	
	//Time balance is updated individually because we want to save it's value each time a user gains
	// a five minute credit.
	public void addTimeBalance(int minutes) {
		this.timeBalance += minutes;
		this.updateObserver("timeBalance");
	}
	
	//When the total charge is updated then the user has successfully ended a rent
	// (returned the bike and received athe bill without errors).
	//Then it's the time to update all the other attributes of user report.
	public void addTotalCharges(int charge) {
		this.totalCharges += charge;
		this.updateObserver("numberOfRides");
		this.updateObserver("timeOnBike");
		this.updateObserver("totalCharges");
	}

	@Override
	public void attach(Observer observer) {
		this.userReport = observer;		
	}

	@Override
	public void detach(Observer observer) {
		this.userReport = null;
	}

	@Override
	public void updateObserver(String operationType) {
		try {
			userReport.update(this.userID, operationType);
		} catch (UnknownOperationTypeException e) {
			System.err.println("Unknown operation type while updating the users report");
		}
	}

}
