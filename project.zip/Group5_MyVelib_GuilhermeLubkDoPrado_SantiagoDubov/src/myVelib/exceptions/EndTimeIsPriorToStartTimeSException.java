package myVelib.exceptions;

/**
 * EndTimeIsPriorToStartTimeSException 
 * <p>Is throw when the end time of a ride is prior to the start time,
 * which means that there's an error on the CLUI input
 */
public class EndTimeIsPriorToStartTimeSException extends Exception{
	private static final long serialVersionUID = -6674234178511380936L;

	public EndTimeIsPriorToStartTimeSException() {
		super();
	}
}
