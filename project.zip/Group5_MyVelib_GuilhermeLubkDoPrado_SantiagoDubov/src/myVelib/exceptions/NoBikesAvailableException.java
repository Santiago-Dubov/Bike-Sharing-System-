package myVelib.exceptions;

/**
 * NoBikesAvailableException
 * Is throw when there are no bikes of the desired type.
 */
public class NoBikesAvailableException extends Exception{
	private static final long serialVersionUID = -7729986679132283573L;
	
	public NoBikesAvailableException() {
		super();
	}
	
}
