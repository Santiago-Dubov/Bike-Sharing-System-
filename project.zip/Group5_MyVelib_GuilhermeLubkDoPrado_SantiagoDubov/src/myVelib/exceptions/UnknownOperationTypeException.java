package myVelib.exceptions;

/**
 * UnknownOperationTypeException 
 * Is throw when the operationType variable is misspelled or updated without
 * proper update on the observers concrete implementation
 */
public class UnknownOperationTypeException extends Exception{
	private static final long serialVersionUID = -6674204178511380936L;

	public UnknownOperationTypeException() {
		super();
	}
}
