package myVelib.exceptions;

/**
 * UnknownPolicyTypeException 
 * Is throw when the operationPolicy variable is misspelled or updated without
 * proper update on the RidePlanning block.
 */
public class UnknownPolicyException extends Exception{
	private static final long serialVersionUID = -6674204178511380936L;

	public UnknownPolicyException() {
		super();
	}
}
