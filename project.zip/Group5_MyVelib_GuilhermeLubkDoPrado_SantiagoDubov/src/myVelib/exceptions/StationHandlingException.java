package myVelib.exceptions;

/**
 * StationHandlingException
 * <p>Is throw when some parameter to update a core's station
 * is incorrect.
 */
public class StationHandlingException extends Exception{
	private static final long serialVersionUID = -6674204178511382336L;
	
	public StationHandlingException() {
		super();
	}
}
