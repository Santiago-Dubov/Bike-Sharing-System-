package myVelib.exceptions;

/**
 * NoVacancyException
 * Is throw when the there's no vacancy in a station and a user
 * tries to return a bike.
 */
public class NoVacancyException extends Exception{
	private static final long serialVersionUID = -6674204178511382336L;
	
	public NoVacancyException() {
		super();
	}
}
