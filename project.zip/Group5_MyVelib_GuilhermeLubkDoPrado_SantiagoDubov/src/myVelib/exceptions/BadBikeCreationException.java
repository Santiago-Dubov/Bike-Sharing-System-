package myVelib.exceptions;

/**
 * BadBikeCrestionException
 * <p>Threw when trying to create a new bike with an unknown bike
 * type.
 */
public class BadBikeCreationException extends Exception{
	
	private static final long serialVersionUID = -4367580505273436440L;
	private String bikeType;
	
	public BadBikeCreationException(String bikeType) {
		super();
		this.bikeType = bikeType;
	}

	public String getBikeType() {
		return this.bikeType;
	}
	

}
