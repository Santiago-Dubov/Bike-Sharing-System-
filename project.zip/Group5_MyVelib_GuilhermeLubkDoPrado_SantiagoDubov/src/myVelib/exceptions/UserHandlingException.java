package myVelib.exceptions;

/**
 * UserHandlingException
 * <p>Is throw when some parameter to update a core's user
 * is incorrect.
 */
public class UserHandlingException extends Exception{
	private static final long serialVersionUID = -6674204178511382336L;
	
	public UserHandlingException() {
		super();
	}
}
