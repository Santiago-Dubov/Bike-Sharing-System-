package myVelib.clui;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import myVelib.core.CoreMyVelib;
import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.exceptions.StationHandlingException;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.exceptions.UserHandlingException;
import myVelib.supportClasses.Coord;

public class VelibSystem {
	
	//System.err.println("Error!");
	private static Map<String, CoreMyVelib> velibSystemsList;
	
	public VelibSystem() {

	}
	
	public static void main(String[] args) {
		//Start the program, initialize it with the default settings
		//	and begin receiving user commands
		String[] arguments;
		String command;
		velibSystemsList = new HashMap<String, CoreMyVelib>();
		
		//Initialize the program with a standard configuration
		initialization();
		
		//Enter (getCommand-interpret it) loop until user quit the system
		while(true) {
			try {
				command = getCommand("Waiting for next command (help): ");
				if(command.isBlank()) {
					System.err.println("Please enter a valid command (help / printAllCommands).\n");
				}else {
					arguments = command.split(" ");
					interpreter(arguments);
				}
			} catch (Exception e) {
				//Don't do anything
				//avoid errors CTRL related
			}
		}
	}
	
	//This function is called to initialize the CLUI, display the initial informations to the
	//	user and load the initial setup file.
	public static void initialization() {
		System.out.println("Initializing Velib System...");
		System.out.println("Loading initial state from my_velib.ini");
		CoreMyVelib core = null;

		try
		{
			FileInputStream fileIn = new FileInputStream("my_velib.ini");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			core = (CoreMyVelib) in.readObject(); // requires casting into Employee type
			in.close();
			fileIn.close();
			velibSystemsList.put("CityA", core);
			System.out.println("A standard Velib network was created on CityA. For more details type \"display CityA\"\n");	
		}catch(IOException i)
		{
			System.err.println("Error in creating standard city. Verify the presence of \"my_velib.ini\" file.\n"
					+ "Or type \"createStandardScenario my_velib.ini\" to create one.\n");
			return;
		}catch(ClassNotFoundException c)
		{
			System.err.println("Error in creating standard city. Verify the presence of \"my_velib.ini\" file.\n"
					+ "Or type \"createStandardScenario my_velib.ini\" to create one.\n");
			return;
		}

	}
	
	public static String getCommand(String message){
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		
		try {
			System.out.print(message);
			if(input.hasNextLine()) {
				String com = input.nextLine();
				return com;
			}else {
				input.next();
				return null;
			}
		} catch (Exception e) {
			
		}
		return null;
			
	}
	
	private static void interpreter(String[] args) {
		
		if(args.length == 1) {
			if(args[0].equals("quit")) {
				System.out.println("You're about to close the system. All non-saved modifications will be lost. Are you sure you want to proceed? (yes/no)");
				String answer;
				
				while(true) {
					answer = getCommand("Quit ? ");
					if(answer.isBlank()) {
						System.err.println("Please enter a valid command (yes/no)");
					}else if(answer.equals("yes")) {
						System.out.println("Closing the system...");
						System.out.println("System closed.");
						System.exit(0);
					}else if(answer.equals("no")) {
							break;
					}else {
						System.err.println("Please enter a valid command (yes/no).");
					}
				}
			}else if(args[0].equals("help") || args[0].equals("printAllCommands")) {
				printAllCommands();
			}else if(args[0].equals("displayAvailableNetworks")) {
				displayAvailableNetworks();
			}else if(args[0].equals("save")) {
				save();
			}else if(args[0].equals("load")) {
				load();
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
			
		}else if(args.length == 2) {
			if(args[0].equals("createStandardScenario")) {
				createStandardScenario(args[1]);
			}else if(args[0].equals("display")){
				display(args[1]);
			}else if(args[0].equals("setup")) {
				setup(args[1]);
			}else if(args[0].equals("removeVelibNetwork")) {
				removeVelibNetwork(args[1]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		}else if(args.length == 3){
			if(args[0].equals("displayStation")) {
				displayStation(args[1], args[2]);
			}else if(args[0].equals("displayUser")) {
				displayUser(args[1], args[2]);
			}else if(args[0].equals("offline")) {
				offline(args[1], args[2]);
			}else if(args[0].equals("online")) {
				online(args[1], args[2]);
			}else if(args[0].equals("sortStation")) {
				sortStation(args[1], args[2]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		} else if(args.length == 4){
			if(args[0].equals("addBikes")) {
				addBikes(args[1], args[2], args[3]);
			}else if(args[0].equals("updateStation")) {
				updateStation(args[1], args[2], args[3]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		} else if(args.length == 5){
			if(args[0].equals("updateUserLocation")) {
				updateUserLocation(args[1], args[2], args[3], args[4]);
			}else{
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		} else if(args.length == 6){
			if(args[0].equals("setup")) {
				setup(args[1], args[2], args[3], args[4], args[5]);
			}else if(args[0].equals("addStation")) {
				addStation(args[1], args[2], args[3], args[4], args[5]);
			}else{
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		}else if(args.length == 7){
			if(args[0].equals("addUser")) {
				addUser(args[1], args[2], args[3], args[4], args[5], args[6]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		}else if(args.length == 8){
			if(args[0].equals("planRide")) {
				planRide(args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		}else if(args.length == 9){
			if(args[0].equals("returnBike")) {
				returnBike(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		}else if(args.length == 10){
			if(args[0].equals("rentBike")) {
				rentBike(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
			}else {
				System.err.println("\nCommand unknown, please enter a valid command (help)\n");
			}
		}else{
			System.err.println("\nCommand unknown, please enter a valid command (help)\n");
		}
		
	}

	private static void displayAvailableNetworks() {
		System.out.println("\nAvailable networks:");
		for(String velibNetworkName : velibSystemsList.keySet()) {
			System.out.println("- " + velibNetworkName);
		}
		System.out.println("");
	}

	private static void display(String velibnetworkName) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			System.out.println();
			
			System.out.println("Stations of " + velibnetworkName);
			velibSystemsList.get(velibnetworkName).displayAllStations();
			
			System.out.println("\nUsers of " + velibnetworkName + ":");
			velibSystemsList.get(velibnetworkName).displayAllUsers();

			System.out.println();
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
		
	}
	
	private static void displayStation(String velibnetworkName, String stationID) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			if(stationID.matches("[0-9]+")) {
				System.out.println();
				System.out.println("Station - ID = " + stationID + ":");
				try {
					velibSystemsList.get(velibnetworkName).displayStation(Integer.parseInt(stationID));
				} catch (StationHandlingException e) {
					System.err.println(velibnetworkName + " doens't have a station with ID = " + stationID + "\n");
				}
				System.out.println();
			}else {
				System.err.println("stationID must contain only digits");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void displayUser(String velibnetworkName, String userID) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			if(userID.matches("[0-9]+")) {
				System.out.println();
				System.out.println("User - ID = " + userID + ":");
				try {
					velibSystemsList.get(velibnetworkName).displayUser(Integer.parseInt(userID));
				} catch (UserHandlingException e) {
					System.err.println(velibnetworkName + " doens't have a user with ID = " + userID + "\n");
				}
				System.out.println();
			}else {
				System.err.println("userID must contain only digits");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void addStation(String velibnetworkName, String GPSx, String GPSy, String stationType, String nSpaces) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).addStation(new Coord(Double.valueOf(GPSx), Double.valueOf(GPSy)), stationType, Integer.valueOf(nSpaces));
				System.out.println("The station was added to " + velibnetworkName + ".");
			} catch (NumberFormatException | StationHandlingException e) {
				System.err.println("\nStation data incorrect. GPS coordenates must be composed of real numbers. Station type must be either \"plus\" or \"standard\".\n"
						+ "And nSpaces must be a non-zero positive number.");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void addBikes(String velibnetworkName, String stationID, String nBikes) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			if(velibSystemsList.get(velibnetworkName).getStationsID().contains(Integer.valueOf(stationID))) {
				try {
					int numBikes = Integer.valueOf(nBikes);
					int eBikes = (int) Math.floor(((float) numBikes)/2);
					int mBikes = (int) Math.ceil(((float) numBikes)/2);
					
					for(int i = 0; i < mBikes; i++) {
						velibSystemsList.get(velibnetworkName).addBike(Integer.valueOf(stationID), "MECHANICAL");
					}
					for(int i = 0; i < eBikes; i++) {
						velibSystemsList.get(velibnetworkName).addBike(Integer.valueOf(stationID), "ELECTRICAL");
					}
					
					System.out.println("Bikes successfully added to the station " + stationID + ".");
					
				} catch (NoVacancyException e) {
					System.err.println("The station is full, not all bikes were added.\n");
				}catch (NumberFormatException n) {
					System.err.println("Station ID must be an integer number.\n");
				}
			}else {
				System.err.println("Station not found. Check its ID number.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void addUser(String velibnetworkName, String userName, String cardType, String GPSx, String GPSy,
			String creditCardNumber) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).addUser(userName, cardType, new Coord(Double.valueOf(GPSx), Double.valueOf(GPSy)), creditCardNumber);
				System.out.println(userName + " was added to " + velibnetworkName + ".");
			} catch (NumberFormatException | UserHandlingException e) {
				System.err.println("\nUser data incorrect. Card type must be either \"Vmax\", \"VLibre\" or \"none\". GPS coordenates must be composed of real numbers.\n"
						+ "And credit card number must be a 16 digit valid number.");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
		
	}
	
	private static void updateStation(String velibnetworkName, String stationID, String stationType) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			if(velibSystemsList.get(velibnetworkName).getStationsID().contains(Integer.valueOf(stationID))) {
				try {
					velibSystemsList.get(velibnetworkName).updateStation(Integer.valueOf(stationID), stationType);
					System.out.println("Station " + stationID + " was updated to " + stationType + ".");
				} catch (NumberFormatException | StationHandlingException e) {
					System.err.println("Station type must be either \"plus\" or \"standard\".\n");
				}
			}else {
				System.err.println("Station not found. Check its ID number.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}		
	}
	
	private static void updateUserLocation(String velibnetworkName, String userID, String GPSx, String GPSy) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).updateUser(Integer.valueOf(userID), new Coord(Double.valueOf(GPSx), Double.valueOf(GPSy)));
				System.out.println("User " + userID + " had its position updated.");
			} catch (UserHandlingException e) {
				System.err.println("User not found.\n");
			}catch (NumberFormatException n) {
				System.err.println("Incorrect command. User ID must be an integer number and GPS coordenates must be composed of real numbers.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void offline(String velibnetworkName, String stationID) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			if(velibSystemsList.get(velibnetworkName).getStationsID().contains(Integer.valueOf(stationID))) {
				try {
					velibSystemsList.get(velibnetworkName).updateStation(Integer.valueOf(stationID), false);
					System.out.println("Station " + stationID + " was shut down.\n");
				} catch (NumberFormatException e) {
					System.err.println("Station type must be either \"plus\" or \"standard\".\n");
				}
			}else {
				System.err.println("Station not found. Check its ID number.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void online(String velibnetworkName, String stationID) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			if(velibSystemsList.get(velibnetworkName).getStationsID().contains(Integer.valueOf(stationID))) {
				try {
					velibSystemsList.get(velibnetworkName).updateStation(Integer.valueOf(stationID), true);
					System.out.println("Station " + stationID + " is online.\n");
				} catch (NumberFormatException e) {
					System.err.println("Station type must be either \"plus\" or \"standard\".\n");
				}
			}else {
				System.err.println("Station not found. Check its ID number.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void planRide(String velibnetworkName, String iniGPSx, String iniGPSy, String endGPSx, String endGPSy, String bikeType, String ridePolicy) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).planRide(new Coord(Double.valueOf(iniGPSx), Double.valueOf(iniGPSy)), 
						new Coord(Double.valueOf(endGPSx), Double.valueOf(endGPSy)), bikeType, ridePolicy);
			} catch (NumberFormatException e) {
				System.err.println("GPS coordenates must be composed of real numbers.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void rentBike(String velibnetworkName, String userID, String stationID, String bikeType, String year, String month,
			String day, String hour, String minute) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).rentBike(Integer.valueOf(userID), Integer.valueOf(stationID), bikeType, 
						LocalDateTime.of(Integer.valueOf(year), Integer.valueOf(month), Integer.valueOf(day), Integer.valueOf(hour), Integer.valueOf(minute)));
				System.out.println("Rent operation sucessfully realized.\n");
			}catch (NumberFormatException n) {
				System.err.println("Incorrect data entry. UserID, StationId and the date variables must be integer numbers.\n");
			}catch (NoBikesAvailableException nba) {
				System.err.println("There no bikes of this type available at this station.\n");
			}catch (UserHandlingException uh) {
				System.err.println("User is not at the station to perform this rent operation.\n");
			}catch (StationHandlingException sh) {
				System.err.println("The station is offline and cannot be used.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}

	private static void returnBike(String velibnetworkName, String userID, String stationID, String year, String month,
			String day, String hour, String minute) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).returnBike(Integer.valueOf(userID), Integer.valueOf(stationID), 
						LocalDateTime.of(Integer.valueOf(year), Integer.valueOf(month), Integer.valueOf(day), Integer.valueOf(hour), Integer.valueOf(minute)));
				System.out.println("Return operation sucessfully realized. Ride finalized\n");
			}catch (NumberFormatException n) {
				System.err.println("Incorrect data entry. UserID, StationId and the date variables must be integer numbers.\n");
			}catch (UserHandlingException uh) {
				System.err.println("User is not at the station to perform this return operation.\n");
			}catch (NoVacancyException nv) {
				System.err.println("The station is full and can't receive the user's bike. The return operation was not performed.\n");
			}catch (EndTimeIsPriorToStartTimeSException wd) {
				System.err.println("The end time for the ride is prior to its start time. The return operation was not performed.\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void sortStation(String velibnetworkName, String sortPolicy) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			try {
				velibSystemsList.get(velibnetworkName).displaySortedStations(sortPolicy);
			} catch (UnknownOperationTypeException e) {
				System.err.println("Unknown required sort policy (mostUsed / mostOccupied).\n");
			}
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}		
	}
	
	private static void removeVelibNetwork(String velibnetworkName) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			velibSystemsList.remove(velibnetworkName);
			System.out.println(velibnetworkName + " was sucessfully removed.");
		}else {
			System.err.println("Velibnetwork with the given name not found.\n");
		}
	}
	
	private static void printAllCommands() {
		System.out.println("\nHere's a list of available commands and their arguments:");
		System.out.println("- setup velibnetworkName");
		System.out.println("- setup velibnetworkName nStations nSpaces s nBikes");
		System.out.println("- displayAvailableNetworks");
		System.out.println("- display velibnetworkName");
		System.out.println("- displayStation velibnetworkName stationID");
		System.out.println("- displayUser velibnetworkName userID");
		System.out.println("- addStation velibnetworkName LocationGPSx LocationGPSy stationType nSpaces");
		System.out.println("- addBikes velibnetworkName stationID nBikes");
		System.out.println("- addUser velibnetworkName userName cardType LocationGPSx LocationGPSy creditCard");
		System.out.println("- updateStation velibnetworkName stationID stationType");
		System.out.println("- updateUserLocation velibnetworkName userID LocationGPSx LocationGPSy");
		System.out.println("- offline velibnetworkName stationID");
		System.out.println("- online velibnetworkName stationID");
		System.out.println("- planRide velibnetworkName initialLocationGPSx initialLocationGPSy endLocationGPSx endLocationGPSy bikeType ridePolicy");
		System.out.println("- rentBike velibnetworkName userID stationID bikeType year month day hour minute");
		System.out.println("- returnBike velibnetworkName userID stationID year month day hour minute");
		System.out.println("- sortStation velibnetworkName sortPolicy");
		System.out.println("- removeVelibNetwork velibnetworkName");
		System.out.println("- help");
		System.out.println("- printAllCommands");
		System.out.println("- quit");
		System.out.println("- load");
		System.out.println("- save");
		System.out.println();
	}
	
	private static void load() {
		System.out.println("You're about to load an entire setup from the load file. All current modifications will be overwritten. Are you sure you want to proceed? (yes/no)");
		String answer;
		
		while(true) {
			answer = getCommand("Load ? ");
			if(answer.isBlank()) {
				System.err.println("Please enter a valid command (yes/no)");
			}else if(answer.equals("yes")) {
				System.out.println("Loading...");
				Map<String, CoreMyVelib> velibSystem;
				
				
				try
				{
					FileInputStream fileIn = new FileInputStream("saveFileVelibSystem.ser");
					ObjectInputStream in = new ObjectInputStream(fileIn);
					velibSystem = extracted(in); // requires casting into Employee type
					in.close();
					fileIn.close();
					velibSystemsList.clear();
					velibSystemsList.putAll(velibSystem );
					for(CoreMyVelib c : velibSystemsList.values()) {
						c.recoverIDState();
					}
					System.out.println("Load successful.\n");
			
				}catch(IOException i)
				{
					System.err.println("Error in creating loading process. Verify the presence of \"saveFileVelibSystem.ser\" file.\n"
							+ "Or type \"createStandardScenario my_velib.ini\" to create one.\n");
					return;
				}catch(ClassNotFoundException c)
				{
					System.err.println("Error in creating standard city. Verify the presence of \"my_velib.ini\" file.\n"
							+ "Or type \"createStandardScenario my_velib.ini\" to create one.\n");
					return;
				}
				
				break;
				
			}else if(answer.equals("no")) {
					break;
			}else {
				System.err.println("Please enter a valid command (yes/no).");
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static Map<String, CoreMyVelib> extracted(ObjectInputStream in) throws IOException, ClassNotFoundException {
		return (Map<String, CoreMyVelib>) in.readObject();
	}
	
	private static void save() {
		try
		{
			FileOutputStream fileOut = new FileOutputStream("saveFileVelibSystem.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(velibSystemsList);
			out.close();
			fileOut.close();
			System.out.printf("\nAll modifications have been saved in the file \"saveFileVelib.ser\"\n"
					+ "To load this modification enter command \"load\".\n\n");
		}
		catch(IOException i){ 
			System.err.println("Failed to create the standard scenario. Verify file name before trying again.");
		}
	}
	
	private static void setup(String velibnetworkName) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			System.err.println("\nA Velib Network has been already been created at this location (displayAvailableNetworks)\n");
		}else {
			CoreMyVelib core = new CoreMyVelib();
			int N = 10; //num stations
			int M = 100; //num parking spaces
			int nBikes = (int) (0.75*M);
			double R = 4;
			int n1 = (int) Math.sqrt(N) + 1;
			int n2 = (int) M/N;
			int eBikesPerStation = (int) (0.375*M/N) + 1;
			int mBikesPerStation = (int) (0.375*M/N) + 1;
			//System.out.println(mBikesPerStation + "  " + eBikesPerStation);
			for (int i = 1; i < n1+1; i++) {
				for (int j = 1; j < n1+1; j++) {
					if (core.getStationList().size() < N) {
						String stationType;
						if (Math.random() < 0.5) {
							stationType = "plus";
						}
						else {
							stationType = "standard";
						}
						try {
							Coord location = new Coord(i*R/(n1+1),j*R/(n1+1));
							core.addStation(location, stationType, Math.min(n2, M));
							int stationID = core.getStationByLocation(location).getStationID();
							for (int k = 0; k < eBikesPerStation; k++) {
								if (core.getTotalNumberOfBikes() < nBikes) {
									core.addBike(stationID,  "Electrical");
								}
							}
							for (int k = 0; k < mBikesPerStation; k++) {
								if (core.getTotalNumberOfBikes() < nBikes) {
									core.addBike(stationID, "mechanical");
								}
							}
						} catch (Exception e) {
							
						}
						M -= Math.min(n2, M);
					}
					else {
						break;
					}
				}
			}
			velibSystemsList.put(velibnetworkName, core);
			System.out.println("\nA standard Velib Network has been created in " + velibnetworkName + ".\n");
		}
	}
	
	private static void setup(String velibnetworkName, String nStations, String nSpaces, String s, String numBikes) {
		if(velibSystemsList.containsKey(velibnetworkName)) {
			System.err.println("\nA Velib Network has been already been created at this location (displayAvailableNetworks)\n");
		}else {	
			try {
				int N = Integer.parseInt(nStations);
				int M = Integer.parseInt(nSpaces);
				double R = Double.parseDouble(s);
				int nBikes = Integer.parseInt(numBikes);
				
				M = N*M;
				if(N > 0 && M > 0 && R > 0 && nBikes > 0) {
					if(nBikes <= M) {
						CoreMyVelib core = new CoreMyVelib();
						int n1 = (int) Math.sqrt(N) + 1;
						int n2 = (int) M/N;
						int eBikesPerStation = (int) (0.3*((double) nBikes / (double) N) );
						int mBikesPerStation = (int) (0.7*((double) nBikes / (double) N) );
						
						if((eBikesPerStation+mBikesPerStation) > n2) {
							mBikesPerStation -= 1;
						}else if((eBikesPerStation+mBikesPerStation) < ((double) nBikes / (double) N)) {
							eBikesPerStation += 1;
						}else if((eBikesPerStation+mBikesPerStation) > ((double) nBikes / (double) N)) {
							mBikesPerStation -= 1;
						}
						
						//System.out.println(mBikesPerStation + "  " + eBikesPerStation);
						for (int i = 1; i < n1+1; i++) {
							for (int j = 1; j < n1+1; j++) {
								if (core.getStationList().size() < N) {
									String stationType;
									if (Math.random() < 0.5) {
										stationType = "plus";
									}
									else {
										stationType = "standard";
									}
									try {
										Coord location = new Coord(i*R/(n1+1),j*R/(n1+1));
										core.addStation(location, stationType, Math.min(n2, M));
										int stationID = core.getStationByLocation(location).getStationID();
										for (int k = 0; k < eBikesPerStation; k++) {
											if (core.getTotalNumberOfBikes() < nBikes) {
												core.addBike(stationID,  "Electrical");
											}
										}
										for (int k = 0; k < mBikesPerStation; k++) {
											if (core.getTotalNumberOfBikes() < nBikes) {
												core.addBike(stationID, "mechanical");
											}
										}
									} catch (Exception e) {
										
									}
									M -= Math.min(n2, M);
								}
								else {
									break;
								}
							}
						}
						velibSystemsList.put(velibnetworkName, core);
						System.out.println("\nA Velib Network has been created in " + velibnetworkName + ".\n");
					}else {
						System.err.println("\nThere are more bikes than available parking spaces. Creation of network impossible.\n");
					}
				}else if(N == 0){
					CoreMyVelib core = new CoreMyVelib();
					velibSystemsList.put(velibnetworkName, core);
					System.out.println("\nA Velib Network has been created in " + velibnetworkName + ".\n");
					
				}else {
					System.err.println("\nInvalid arguments. Make sure \"nStations\", \"nSpaces\" and \"nBikes\" are positive integers and that \"s\" is a non-zero positive number.\n");
				}
				
			}catch (Exception e) {
				System.err.println("\nInvalid arguments. Make sure \"nStations\", \"nSpaces\" and \"nBikes\" are positive integers and that \"s\" is a non-zero positive number.\n");
			}
		}
	}
	
	public static void createStandardScenario(String filename) {
		CoreMyVelib core = new CoreMyVelib();
		int N = 10; //num stations
		int M = 100; //num parking spaces
		int nBikes = (int) (0.75*M);
		double R = 4;
		int n1 = (int) Math.sqrt(N) + 1;
		int n2 = (int) M/N;
		int eBikesPerStation = (int) (0.375*M/N) + 1;
		int mBikesPerStation = (int) (0.375*M/N) + 1;
		//System.out.println(mBikesPerStation + "  " + eBikesPerStation);
		for (int i = 1; i < n1+1; i++) {
			for (int j = 1; j < n1+1; j++) {
				if (core.getStationList().size() < N) {
					String stationType;
					if (Math.random() < 0.5) {
						stationType = "plus";
					}
					else {
						stationType = "standard";
					}
					try {
						Coord location = new Coord(i*R/(n1+1),j*R/(n1+1));
						core.addStation(location, stationType, Math.min(n2, M));
						int stationID = core.getStationByLocation(location).getStationID();
						for (int k = 0; k < eBikesPerStation; k++) {
							if (core.getTotalNumberOfBikes() < nBikes) {
								core.addBike(stationID,  "Electrical");
							}
						}
						for (int k = 0; k < mBikesPerStation; k++) {
							if (core.getTotalNumberOfBikes() < nBikes) {
								core.addBike(stationID, "mechanical");
							}
						}
					} catch (Exception e) {
						
					}
					M -= Math.min(n2, M);
				}
				else {
					break;
				}
			}
		}
		System.out.println("");
		core.displayAllStations();
		
		try
		{
			FileOutputStream fileOut = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(core);
			out.close();
			fileOut.close();
			System.out.printf("\nSerialized standard scenario saved on " + filename + "\n"
					+ "In order to load it, type \"quit\" and restart the program.\n\n");
		}
		catch(IOException i){ 
			System.err.println("Failed to create the standard scenario. Verify file name before trying again.");
		}
		
		
	}

}
