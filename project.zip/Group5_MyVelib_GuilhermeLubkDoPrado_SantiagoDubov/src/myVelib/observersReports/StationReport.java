package myVelib.observersReports;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import myVelib.coreAttributes.Station;
import myVelib.exceptions.UnknownOperationTypeException;

/**
 *StationReport class
 *<p>This class is an implementation of the observer pattern and contains
 *a set of hash tables to store all the statistics of each station. Each of the statistics,
 *and the station itself are accessible via the station ID number.
 *<p>This observer watches over many observables and keeps track of their past. In order to do so,
 *we added an method, addStation, that allows the initialization of the necessary data
 *structures.
 *<p>The numberOfBikes statistic is calculated when a station is added then is only
 *updated after each rent, return or addition operation.
 */
public class StationReport implements Observer, java.io.Serializable{
	
	private static final long serialVersionUID = 894847052520527607L;
	private Map<Integer, Station> stationList;
	private Map<Integer, Integer> numberRents;
	private Map<Integer, Integer> numberReturns;
	private Map<Integer, Integer> numberOfBikes;
	private Map<Integer, Integer> numberOfSpaces;
	
	public StationReport() {
		super();
		stationList = new HashMap<Integer, Station>();
		numberRents = new HashMap<Integer, Integer>();
		numberReturns = new HashMap<Integer, Integer>();
		numberOfBikes = new HashMap<Integer, Integer>();
		numberOfSpaces = new HashMap<Integer, Integer>();
	}
	
	//  When a station is added, its numberOfBikes number is calculated by looking at
	//	the state of the parking spaces. After this initial calculation,
	//	the numberOfBikes variable is only updated when a a bike is added, rented
	//	or returned. We don't consider, in this version, the removal of bikes
	// 	for any other reason (like maintenance). This is a simplification due to
	//	time constraints.
	public void addStation(Station station) {
		stationList.put(station.getStationID(), station);
		numberRents.put(station.getStationID(), 0);
		numberReturns.put(station.getStationID(), 0);
		numberOfBikes.put(station.getStationID(), 0);
		numberOfSpaces.put(station.getStationID(), station.getParkingSpaces().size());
	}

	public int getNumberRents(int stationID) {
		return numberRents.get(stationID);
	}

	public int getNumberReturns(int stationID) {
		return numberReturns.get(stationID);
	}

	public int getNumberOfBikes(int stationID) {
		return numberOfBikes.get(stationID);
	}
	
	public int getNumberOfSpaces(int stationID) {
		return numberOfSpaces.get(stationID);
	}
	
	public double getOccupation(int stationID) {
		return ((double) numberOfBikes.get(stationID) / (double) numberOfSpaces.get(stationID));
	}

	//If a bike is added, numberOfBikes is increased by one (the same happens when a bike is returned).
	//If a bike is rented, numberOfBikes is decreased by one.
	//Rents, returns and additions can only be made if there are available parking spaces or bikes
	//	left, so no verification is done here.
	@Override
	public void update(int ID, String operationType) throws UnknownOperationTypeException {
		if(operationType.equals("addedNewBike")) {
			int newNumberOfBikes = numberOfBikes.get(ID) + 1;
			numberOfBikes.put(ID, newNumberOfBikes);
		}else if(operationType.equals("rent")) {
			int newNumberRents = numberRents.get(ID) + 1;
			numberRents.put(ID, newNumberRents);
			int newNumberOfBikes = numberOfBikes.get(ID) - 1;
			numberOfBikes.put(ID, newNumberOfBikes);
		}else if(operationType.equals("return")) {
			int newNumberReturns = numberReturns.get(ID) + 1;
			numberReturns.put(ID, newNumberReturns);
			int newNumberOfBikes = numberOfBikes.get(ID) + 1;
			numberOfBikes.put(ID, newNumberOfBikes);
		}else {
			throw new UnknownOperationTypeException();
		}
		
	}
	
	public ArrayList<Station> getSortedStations(String sortPolicy) throws UnknownOperationTypeException {
		if (sortPolicy.equalsIgnoreCase("mostUsed")) {
			ArrayList<Station> stlst = new ArrayList<>(Arrays.asList(this.stationList.values().toArray(new Station[0])));
			Collections.sort(stlst, Comparator.comparing(s -> (-1.0*((double) this.getNumberRents(s.getStationID()) + (double) this.getNumberReturns(s.getStationID())))));
			//Collections.sort(stlst, Collections.reverseOrder());
			return stlst;
		}
		if (sortPolicy.equalsIgnoreCase("mostOccupied")) {
			ArrayList<Station> stlst = new ArrayList<>(Arrays.asList(this.stationList.values().toArray(new Station[0])));
			Collections.sort(stlst, Comparator.comparing(s -> (-1*this.getOccupation(s.getStationID()))));
			return stlst;
		}
		throw new UnknownOperationTypeException();
	}
	
	
}
