package myVelib.observersReports;

/**
 * Observable interface
 * Allows for proper implementation of the observer pattern on the Stations and Users
 */
public interface Observable {
	public void attach(Observer observer);
	public void detach(Observer observer);
	public void updateObserver(String operationType);
}
