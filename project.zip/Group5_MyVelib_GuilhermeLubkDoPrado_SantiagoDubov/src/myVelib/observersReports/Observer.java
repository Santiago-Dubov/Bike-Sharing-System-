package myVelib.observersReports;

import myVelib.exceptions.UnknownOperationTypeException;

/**
 * Observer interface
 * This interface is the basis for the report classes
 * <p>In order to update a subject its ID and the operation type are necessary.
 * <p>If the operationType is unknown an exception is thrown. This is done to ensure
 * that, if further statistics are added or simplifications undone, the evaluatio of
 * operation type will be updated or an error easily identified.
 */
public interface Observer {
	public void update(int ID, String operationType) throws UnknownOperationTypeException;
}
