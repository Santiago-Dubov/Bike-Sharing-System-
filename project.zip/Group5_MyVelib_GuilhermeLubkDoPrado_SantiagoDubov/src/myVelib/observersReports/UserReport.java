package myVelib.observersReports;

import java.util.HashMap;
import java.util.Map;

import myVelib.coreAttributes.User;
import myVelib.exceptions.EndTimeIsPriorToStartTimeSException;
import myVelib.exceptions.UnknownOperationTypeException;
import myVelib.supportClasses.DifferenceInMinutes;

/**
 *UserReport class
 *<p>This class is an implementation of the observer pattern and contains
 *a set of hash tables to store all the statistics of each user. Each of the statistics,
 *and the user itself are accessible via the user ID number.
 * *<p>This observer watches over many observables and keeps track of their past. In order to do so,
 *we added an method, addUser, that allows the initialization of the necessary data
 *structures.
 */

public class UserReport implements Observer, java.io.Serializable{
	
	private static final long serialVersionUID = 1180964659072476854L;
	private Map<Integer, User> userList;
	private Map<Integer, Integer> numberOfRides;
	private Map<Integer, Integer> timeOnBike;
	private Map<Integer, Integer> totalCharges;
	private Map<Integer, Integer> totalTimeCredit;

	public UserReport() {
		userList = new HashMap<Integer, User>();
		numberOfRides = new HashMap<Integer, Integer>();
		timeOnBike = new HashMap<Integer, Integer>();
		totalCharges = new HashMap<Integer, Integer>();
		totalTimeCredit = new HashMap<Integer, Integer>();
	}
	
	public void addUser(User user) {
		userList.put(user.getUserID(), user);
		numberOfRides.put(user.getUserID(), 0);
		timeOnBike.put(user.getUserID(), 0);
		totalCharges.put(user.getUserID(), 0);
		totalTimeCredit.put(user.getUserID(), 0);
	}
	
	public int getNumberOfRides(int userID) {
		return numberOfRides.get(userID);
	}

	public int getTimeOnBike(int userID) {
		return timeOnBike.get(userID);
	}

	public int getTotalCharges(int userID) {
		return totalCharges.get(userID);
	}

	public int getTotalTimeCredit(int userID) {
		return totalTimeCredit.get(userID);
	}

	@Override
	public void update(int ID, String operationType) throws UnknownOperationTypeException {
		//The value gained for returning a bike to a plus station has been hard coded here
		//	for simplification, meaning that this version of the program will be improved 
		//	if possible.
		if(operationType.equals("timeBalance")) {
			int newTimeBalance = totalTimeCredit.get(ID) + 5;
			totalTimeCredit.put(ID, newTimeBalance);
		//Number of rides is increased by one, and this is called everytime an user
		// successfully ended a ride and returned a bike.
		//This attribute will only count FINISHED RIDES
		}else if(operationType.equals("numberOfRides")) {
			int newNumberOfRides = numberOfRides.get(ID) + 1;
			numberOfRides.put(ID, newNumberOfRides);
		//This error will be catched before allowing the user to return the bike, therefore this method of
		// user report will never be called if there's an error with the return bike parameters.
		//Even so, the exception is treated here, in order to provide a reminder of an untreated exception
		}else if(operationType.equals("timeOnBike")) {
			int newTimeOnBike;
			try {
				newTimeOnBike = timeOnBike.get(ID) + DifferenceInMinutes.returnDifferenceInMinutes(userList.get(ID).getInitialRentTime(), userList.get(ID).getEndRentTime());
				timeOnBike.put(ID, newTimeOnBike);
			} catch (EndTimeIsPriorToStartTimeSException e) {
				System.err.println("Coudn't update userReport on userID: " + ID + ". End time of the ride is prior to start time.");
			}
		}else if(operationType.equals("totalCharges")) {
			totalCharges.put(ID, userList.get(ID).getTotalCharges());
		}else {
			throw new UnknownOperationTypeException();
		}
	}
}
