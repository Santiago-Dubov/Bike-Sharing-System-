package myVelib.bikeFactory;

import myVelib.supportClasses.SerialNumberGenerator;

/**
 * ElectricalBike class
 * Has a unique ID even when compared to stations and parking spaces
 */
public class ElectricalBike implements Bike, java.io.Serializable {

	private static final long serialVersionUID = -2635303396375856727L;
	private int bikeID;
	private String bikeType;
	
	public ElectricalBike() {
		SerialNumberGenerator sng = SerialNumberGenerator.getInstance();
		this.bikeID = sng.getNextSerialNumber();
		this.bikeType = "ELECTRICAL";
	}

	@Override
	public int getBikeID() {
		return this.bikeID;
	}

	public String getBikeType() {
		return bikeType;
	}

}
