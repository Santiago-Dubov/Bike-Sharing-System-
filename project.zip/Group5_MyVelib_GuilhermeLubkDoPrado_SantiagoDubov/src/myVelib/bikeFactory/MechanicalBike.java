package myVelib.bikeFactory;

import myVelib.supportClasses.SerialNumberGenerator;

/**
 * Mechanical Bike class
 * Has a unique ID even when compared to stations and parking spaces
 */
public class MechanicalBike implements Bike, java.io.Serializable {

	private static final long serialVersionUID = -3695150180709044249L;
	private int bikeID;
	private String bikeType;
	
	public MechanicalBike() {
		SerialNumberGenerator sng = SerialNumberGenerator.getInstance();
		this.bikeID = sng.getNextSerialNumber();
		this.bikeType = "MECHANICAL";
	}

	@Override
	public int getBikeID() {
		return this.bikeID;
	}

	public String getBikeType() {
		return bikeType;
	}

}