package myVelib.bikeFactory;

import myVelib.exceptions.BadBikeCreationException;

/**
 * BikeFactory class
 * <p>This class allows the creation of a bike according to the parsed bike type using
 * the simple factory pattern. If new types of bikes are inserted, this class will have to be modified
 * but the Station class and the core can remain untouched.
 *<p>If the bike type argument is not unknown a BadBikeCreationException is thrown.
 */
public class BikeFactory implements java.io.Serializable{
	
	private static final long serialVersionUID = 6281140423408644713L;

	public BikeFactory() {
		super();
	}

	//getBike() will return the select bike type as a Bike object or throw
	//	an exception.
	public Bike getBike(String bikeType) throws BadBikeCreationException{
		if(bikeType.equalsIgnoreCase("ELECTRICAL")) {
			return new ElectricalBike();
		}else if(bikeType.equalsIgnoreCase("MECHANICAL")) {
			return new MechanicalBike();
		}else {
			throw new BadBikeCreationException(bikeType);
		}
	}
}
