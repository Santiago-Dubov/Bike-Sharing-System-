package myVelib.bikeFactory;

/**
 * Bike interface
 * Allows the creation of new types of bike without having to modify the core application nor the CLUI.
 * This is done according to the factory pattern
 *
 */
public interface Bike {
	public int getBikeID();
	public String getBikeType();
}
