/**
 * PlanningStrategy
 * <p>Interface implemented by each ride planning strategy.
 */
package myVelib.ridePlanner;

import java.util.ArrayList;

import myVelib.coreAttributes.Station;
import myVelib.supportClasses.Coord;

public interface PlanningStrategy {
	public void printPlanning(Coord initialGPSLocation, Coord endGPSLocation, String bikeType, ArrayList<Station> stationList);

}
