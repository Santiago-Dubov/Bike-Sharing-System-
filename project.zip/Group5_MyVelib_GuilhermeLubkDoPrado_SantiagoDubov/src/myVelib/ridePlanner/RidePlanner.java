/**
 * RidePlanner class
 * 
 * <p>Used in conjunction with the strategy pattern to calculate the stations a user should visit in order to travel between two coordinates.
 */
package myVelib.ridePlanner;

import java.util.ArrayList;

import myVelib.coreAttributes.Station;
import myVelib.exceptions.UnknownPolicyException;
import myVelib.supportClasses.Coord;

public class RidePlanner implements java.io.Serializable{

	private static final long serialVersionUID = 4149423597433499442L;
	PlanningStrategy planningStrategy;
	
	public RidePlanner(String ridePolicy) throws UnknownPolicyException{
		if (ridePolicy.equalsIgnoreCase("STANDARD")) {
			planningStrategy = new StandardPlanner();
		}
		else {
			throw new UnknownPolicyException();
		}
	}
	
	public void printPlanning(Coord initialGPSLocation, Coord endGPSLocation, String bikeType, ArrayList<Station> stationList) {
		planningStrategy.printPlanning(initialGPSLocation, endGPSLocation, bikeType, stationList);
	}
}
