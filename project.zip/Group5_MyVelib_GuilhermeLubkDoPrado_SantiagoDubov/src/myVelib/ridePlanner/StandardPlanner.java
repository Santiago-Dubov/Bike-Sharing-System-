/**
 * StandardPlanner class
 * 
 * <p>Used to plan a route with no preference for plus stations.
 */
package myVelib.ridePlanner;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import myVelib.coreAttributes.Station;
import myVelib.exceptions.NoBikesAvailableException;
import myVelib.exceptions.NoVacancyException;
import myVelib.supportClasses.Coord;

public class StandardPlanner implements PlanningStrategy, java.io.Serializable{

	private static final long serialVersionUID = -7853396814221495505L;

	public StandardPlanner() {
	}
	
	public void printPlanning(Coord initialGPSLocation, Coord endGPSLocation, String bikeType, ArrayList<Station> stationList) {
		// prints a message for the user with the recommended stations for his desired route
		Station[] stations;
		try {
			stations = StandardPlanner.getStartEndStations(initialGPSLocation, endGPSLocation, bikeType, stationList);
			System.out.println("Go to station at coordinates: " + stations[0].getStationGPSLocation() + " \nEnd ride at " + stations[1].getStationGPSLocation());
		} catch (NoVacancyException e) {
			System.err.println("No available parking spaces in the network, ride not possible");
		} catch (NoBikesAvailableException e) {
			System.err.println("No available bikes of that type in the network");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Station[] getStartEndStations(Coord initialGPSLocation, Coord endGPSLocation, String bikeType, ArrayList<Station> stationList) throws Exception {
		// method which returns an array of size 2 containing the recommended start and end station
		Station closestStartingStation = StandardPlanner.getClosestStartStation(initialGPSLocation, stationList, bikeType);
		Station closestEndStation = StandardPlanner.getClosestEndStation(endGPSLocation, stationList);
		if (closestEndStation.equals(closestStartingStation)) {
			throw new NoVacancyException();
		}
		Station[] stations = {closestStartingStation,closestEndStation};
		return stations;
	}
	public static Station getClosestStartStation(Coord GPSLocation, ArrayList<Station> stationList, String bikeType) throws NoBikesAvailableException {
		// method to find the closest station to a given GPS coordinate which has the required bike type.
		Collections.sort(stationList, Comparator.comparing(s -> GPSLocation.distance(s.getStationGPSLocation())));
		for (Station station : stationList) {
			if (station.hasAvailableBikes(bikeType)) {
				return station;
			}
		}
		throw new NoBikesAvailableException();
		
	}
	
	public static Station getClosestEndStation(Coord GPSLocation, ArrayList<Station> stationList) throws NoVacancyException {
		// method to find the closest station to a given GPS coordinate with available parking spaces.
		Collections.sort(stationList, Comparator.comparing(s -> GPSLocation.distance(s.getStationGPSLocation())));
		for (Station station : stationList) {
			if (station.hasAvailableParkingSpaces()) {
				return station;
			}
		}
		throw new NoVacancyException();
		
	}

}
